# Registro Escolar v1

Aplicação web do Registro Escolar, construída com Next.js App Router, TypeScript, Prisma, PostgreSQL e NextAuth.

## Requisitos locais

- Node.js 20+
- PostgreSQL 15+ ou Docker
- pnpm 9+ (ou npm equivalente)

## Executar localmente

1. Instale as dependências:

   ```bash
   pnpm install
   ```

2. Crie `.env.local` a partir de `.env.example` e preencha os valores locais. Nunca versione esse arquivo.

3. Com PostgreSQL disponível, gere o cliente, aplique o schema e carregue os dados demonstrativos:

   ```bash
   pnpm db:generate
   pnpm db:push
   pnpm db:seed
   ```

4. Inicie a aplicação:

   ```bash
   pnpm dev
   ```

5. Acesse `http://localhost:3000`.

## Produção na Railway

O repositório contém `railway.json` com:

- build: `npm run build`;
- pre-deploy: `npx prisma migrate deploy`;
- inicialização: `npm run start`;
- health check: `/login`.

Na Railway, configure as variáveis `DATABASE_URL`, `NEXTAUTH_URL`, `NEXTAUTH_SECRET`, `DEMO_PROFESSOR_EMAIL` e `DEMO_PROFESSOR_PASSWORD` diretamente no serviço. A `DATABASE_URL` deve referenciar o serviço PostgreSQL da mesma aplicação. O seed deve ser executado somente uma vez em uma base nova de demonstração e não deve ser usado para sobrescrever uma base com dados reais.

## Scripts

- `pnpm dev`: desenvolvimento local.
- `pnpm build`: build de produção.
- `pnpm start`: inicia o build de produção.
- `pnpm lint`: verifica padrões com ESLint.
- `pnpm typecheck`: valida TypeScript.
- `pnpm db:generate`: gera o cliente Prisma.
- `pnpm db:push`: sincroniza o schema em ambiente local.
- `pnpm db:migrate`: cria uma migration em desenvolvimento.
- `pnpm db:deploy`: aplica migrations pendentes em produção.
- `pnpm db:seed`: carrega dados demonstrativos de forma idempotente.
- `pnpm db:studio`: abre o Prisma Studio.

## Segurança

Segredos, senhas, URLs de banco, arquivos de ambiente, dependências, logs, uploads e artefatos temporários estão protegidos pelo `.gitignore`. O arquivo `.env.example` contém somente placeholders.

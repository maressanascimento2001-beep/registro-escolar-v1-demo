import { BarChart3 } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { ReportFiltersClient } from "@/components/reports/report-filters-client";

export default function ReportFiltersPage() { return <><PageHeader eyebrow="Relatórios" title="Gerar relatório" description="Defina os filtros e a ordenação antes de gerar o PDF em formato A4." icon={BarChart3} /><ReportFiltersClient /></>; }

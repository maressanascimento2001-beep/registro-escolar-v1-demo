import { FileText } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { ReportSheet } from "@/components/reports/report-preview";

export default async function StudentReportPage({ searchParams }: { searchParams: Promise<{ studentId?: string }> }) { const params = await searchParams; return <><PageHeader eyebrow="Relatórios" title="Relatório individual" description="Visualize o relatório A4 de um aluno." icon={FileText} /><ReportSheet title="Relatório individual" downloadHref={params.studentId ? `/api/reports/student/${params.studentId}` : undefined} /></>; }

import Link from "next/link";
import { CheckCircle2, FileDown } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";

export default function ReportGeneratingPage() { return <><PageHeader backHref="/reports/filters" eyebrow="Relatórios" title="PDF pronto para revisão" description="Revise os dados antes de gerar o arquivo definitivo." icon={FileDown} /><div className="empty-state" style={{ minHeight: 360 }}><div className="empty-state-symbol" style={{ color: "var(--success)", background: "var(--success-soft)" }}><CheckCircle2 size={26} /></div><h2>Relatório preparado</h2><p>O PDF A4 será gerado com os filtros e a ordenação escolhidos. A prévia completa ficará disponível na próxima camada da implementação.</p><div className="empty-actions"><Link href="/reports/filters" className="button button-light">Ajustar filtros</Link><Link href="/reports/student" className="button button-primary">Abrir prévia</Link></div></div></>; }

import { FileText } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { ReportSheet } from "@/components/reports/report-preview";

export default async function ClassReportPage({ searchParams }: { searchParams: Promise<{ classId?: string }> }) { const params = await searchParams; return <><PageHeader eyebrow="Relatórios" title="Relatório da turma" description="Visualize o relatório A4 da turma selecionada." icon={FileText} /><ReportSheet title="Relatório da turma" downloadHref={params.classId ? `/api/reports/class/${params.classId}` : undefined} /></>; }

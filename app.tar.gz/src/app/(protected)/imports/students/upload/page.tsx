import { FileUp } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { ImportStepper } from "@/components/imports/import-flow";
import { ImportUploadClient } from "@/components/imports/import-clients";

export default function ImportUploadPage() { return <><PageHeader backHref="/classes" eyebrow="Importação de alunos" title="Importar alunos por PDF" description="Envie um PDF textual ou digitalizado com a lista de alunos da turma." icon={FileUp} /><ImportStepper active={1} /><ImportUploadClient /></>; }

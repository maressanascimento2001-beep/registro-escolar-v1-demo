import { GitMerge } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { ImportStepper } from "@/components/imports/import-flow";
import { ImportModeClient } from "@/components/imports/import-clients";

export default function ImportModePage() { return <><PageHeader backHref="/imports/students/preview" eyebrow="Importação de alunos" title="Escolher modo de importação" description="Escolha como os alunos encontrados serão aplicados à lista atual da turma." icon={GitMerge} /><ImportStepper active={3} /><ImportModeClient /></>; }

import { FileCheck2 } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { ImportStepper } from "@/components/imports/import-flow";
import { ImportConfirmClient } from "@/components/imports/import-clients";

export default function ImportConfirmPage() { return <><PageHeader backHref="/imports/students/mode" eyebrow="Importação de alunos" title="Confirmar importação" description="Confira o resumo e confirme a última etapa do fluxo." icon={FileCheck2} /><ImportStepper active={4} /><ImportConfirmClient /></>; }

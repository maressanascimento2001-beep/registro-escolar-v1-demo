import { FileSearch } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { ImportStepper } from "@/components/imports/import-flow";
import { ImportPreviewClient } from "@/components/imports/import-clients";

export default function ImportPreviewPage() { return <><PageHeader backHref="/imports/students/upload" eyebrow="Importação de alunos" title="Visualizar alunos encontrados" description="Revise e corrija nomes e números antes de continuar." icon={FileSearch} /><ImportStepper active={2} /><ImportPreviewClient /></>; }

import Link from "next/link";
import { FileUp, Plus, Printer, School } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { ClassDetailClient } from "@/components/classes/class-detail-client";

export default async function ClassDetailPage({ params }: { params: Promise<{ classId: string }> }) { const { classId } = await params; return <><PageHeader backHref="/classes" eyebrow="Detalhes da turma" title="Turma" description="Dados e alunos da turma selecionada." icon={School} actions={<><Link href={`/imports/students/upload?classId=${classId}`} className="button button-light"><FileUp size={16} />Importar alunos</Link><Link href={`/reports/class?classId=${classId}`} className="button button-light"><Printer size={16} />Imprimir relatórios</Link><Link href={`/records/class?classId=${classId}`} className="button button-primary"><Plus size={16} />Novo registro</Link></>} /><ClassDetailClient classId={classId} /></>; }

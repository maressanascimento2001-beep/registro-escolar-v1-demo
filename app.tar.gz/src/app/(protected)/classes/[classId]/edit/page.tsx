import { School } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { ClassFormClient } from "@/components/classes/class-form-client";

export default async function EditClassPage({ params }: { params: Promise<{ classId: string }> }) { const { classId } = await params; return <><PageHeader backHref={`/classes/${classId}`} eyebrow="Turmas" title="Editar turma" description="Atualize os dados estruturais da turma." icon={School} /><ClassFormClient classId={classId} /></>; }

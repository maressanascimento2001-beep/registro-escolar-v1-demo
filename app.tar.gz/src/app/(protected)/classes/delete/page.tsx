import Link from "next/link";
import { AlertTriangle, Trash2 } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";

export default function DeleteClassPage() { return <><PageHeader backHref="/classes" eyebrow="Turmas" title="Excluir turma" description="Revise esta ação antes de confirmar." icon={Trash2} /><div className="empty-state" style={{ minHeight: 350 }}><div className="empty-state-symbol" style={{ color: "var(--danger)", background: "var(--danger-soft)" }}><AlertTriangle size={25} /></div><h2>Excluir a turma 5º A?</h2><p>A exclusão da turma é uma ação sensível. Esta tela está pronta para receber a confirmação e as validações da próxima sprint.</p><div className="empty-actions"><Link href="/classes" className="button button-light">Cancelar</Link><button className="button button-danger" type="button"><Trash2 size={16} />Excluir turma</button></div></div></>; }

import { School } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { ClassFormClient } from "@/components/classes/class-form-client";

export default function NewClassPage() { return <><PageHeader backHref="/classes" eyebrow="Turmas" title="Nova turma" description="Cadastre uma turma para o ano letivo selecionado." icon={School} /><ClassFormClient /></>; }

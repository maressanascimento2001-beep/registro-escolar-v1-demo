import Link from "next/link";
import { Plus } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { ClassListClient } from "@/components/classes/class-list-client";

export default function ClassesPage() { return <><PageHeader eyebrow="Organização" title="Turmas" description="Gerencie as turmas do ano letivo selecionado." actions={<Link href="/classes/new" className="button button-primary"><Plus size={16} />Nova turma</Link>} /><ClassListClient /></>; }

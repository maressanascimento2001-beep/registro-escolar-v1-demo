import { Search as SearchIcon } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { GlobalSearchClient } from "@/components/search/global-search-client";

export default function GlobalSearchPage() { return <><PageHeader eyebrow="Pesquisa global" title="Encontre tudo rapidamente" description="Busque por aluno, turma ou registro usando a barra superior." icon={SearchIcon} /><GlobalSearchClient /></>; }

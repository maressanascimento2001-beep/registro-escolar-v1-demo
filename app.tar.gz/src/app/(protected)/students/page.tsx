import Link from "next/link";
import { Plus } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { StudentsListClient } from "@/components/students/students-list-client";

export default function StudentsPage() { return <><PageHeader eyebrow="Pessoas" title="Alunos" description="Consulte alunos e acesse suas fichas rapidamente." actions={<Link href="/students/new" className="button button-primary"><Plus size={16} />Cadastrar aluno</Link>} /><StudentsListClient /></>; }

import { GraduationCap } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { StudentFormClient } from "@/components/students/student-form-client";

export default async function EditStudentPage({ params }: { params: Promise<{ studentId: string }> }) { const { studentId } = await params; return <><PageHeader backHref={`/students/${studentId}`} eyebrow="Alunos" title="Editar aluno" description="Atualize os dados cadastrais do aluno." icon={GraduationCap} /><StudentFormClient studentId={studentId} /></>; }

import { ClipboardPenLine } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { StudentHistoryClient } from "@/components/students/student-history-client";

export default async function StudentHistoryPage({ params }: { params: Promise<{ studentId: string }> }) { const { studentId } = await params; return <><PageHeader backHref={`/students/${studentId}`} eyebrow="Histórico do aluno" title="Histórico do aluno" description="Todos os registros em ordem cronológica, independentemente da categoria." icon={ClipboardPenLine} /><StudentHistoryClient studentId={studentId} /></>; }

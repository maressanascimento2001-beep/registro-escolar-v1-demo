import { ClipboardPenLine } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { StudentProfileClient } from "@/components/students/student-profile-client";

export default async function StudentProfilePage({ params }: { params: Promise<{ studentId: string }> }) { const { studentId } = await params; return <><PageHeader backHref="/students" eyebrow="Ficha do aluno" title="Ficha do aluno" description="Acompanhe dados cadastrais e histórico de registros." icon={ClipboardPenLine} /><StudentProfileClient studentId={studentId} /></>; }

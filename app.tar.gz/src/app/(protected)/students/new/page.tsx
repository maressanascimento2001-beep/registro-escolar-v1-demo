import { GraduationCap } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { StudentFormClient } from "@/components/students/student-form-client";

export default function NewStudentPage() { return <><PageHeader backHref="/students" eyebrow="Alunos" title="Cadastrar aluno" description="Adicione um aluno manualmente ao contexto atual." icon={GraduationCap} /><StudentFormClient /></>; }

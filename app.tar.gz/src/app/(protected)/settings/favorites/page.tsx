import { Heart } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { FavoritesClient } from "@/components/settings/settings-clients";

export default function FavoritesPage() { return <><PageHeader eyebrow="Configurações" title="Registros favoritos" description="Defina quais tipos aparecem primeiro na tela de lançamento." icon={Heart} /><FavoritesClient /></>; }

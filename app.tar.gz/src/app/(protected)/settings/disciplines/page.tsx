import { BookOpen } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { DisciplinesClient } from "@/components/settings/settings-clients";

export default function DisciplinesPage() { return <><PageHeader eyebrow="Configurações" title="Disciplinas" description="Cadastre as disciplinas que podem ser vinculadas às turmas." icon={BookOpen} /><DisciplinesClient /></>; }

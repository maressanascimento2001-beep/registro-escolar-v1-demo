import { Copy } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { YearFormClient } from "@/components/settings/year-form-client";

export default function DuplicateAcademicYearPage() { return <><PageHeader backHref="/settings/academic-years" eyebrow="Anos letivos" title="Duplicar ano letivo" description="Copie a estrutura das turmas para um novo ano sem levar alunos ou registros." icon={Copy} /><YearFormClient duplicate /></>; }

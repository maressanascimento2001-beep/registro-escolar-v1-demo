import { CalendarDays } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { YearFormClient } from "@/components/settings/year-form-client";

export default function AcademicYearFormPage() { return <><PageHeader backHref="/settings/academic-years" eyebrow="Anos letivos" title="Novo ano letivo" description="Cadastre o período que será usado no contexto de trabalho." icon={CalendarDays} /><YearFormClient /></>; }

import Link from "next/link";
import { Copy, School, Settings2 } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { YearsClient } from "@/components/settings/settings-clients";

export default function AcademicYearsPage() { return <><PageHeader eyebrow="Configurações" title="Anos letivos" description="Organize turmas e históricos por ano letivo." actions={<Link href="/settings/academic-years/duplicate" className="button button-light"><Copy size={16} />Duplicar ano</Link>} /><YearsClient /><div className="settings-links"><Link href="/settings/disciplines" className="settings-link"><span><Settings2 size={17} /><strong>Disciplinas</strong><small>Gerencie as disciplinas disponíveis para as turmas.</small></span><span>→</span></Link><Link href="/settings/favorites" className="settings-link"><span><School size={17} /><strong>Registros favoritos</strong><small>Escolha quais tipos aparecem primeiro no lançamento.</small></span><span>→</span></Link></div></>; }

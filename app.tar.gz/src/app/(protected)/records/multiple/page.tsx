import { Users } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { RecordComposer } from "@/components/records/record-composer";

export default function MultipleRecordPage() { return <><PageHeader eyebrow="Novo registro" title="Registro para vários alunos" description="Selecione os alunos e aplique o mesmo registro a todos." icon={Users} /><RecordComposer mode="multiple" /></>; }

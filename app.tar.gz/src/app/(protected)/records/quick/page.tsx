import Link from "next/link";
import { ArrowLeft, Sparkles } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { QuickRecordClient } from "@/components/records/quick-record-client";

export default function QuickRecordPage() { return <><PageHeader backHref="/classes" eyebrow="Registro Rápido" title="Lista da turma" description="Selecione um tipo favorito diretamente na lista de alunos." icon={Sparkles} actions={<Link href="/records/individual" className="button button-light"><ArrowLeft size={15} />Modo completo</Link>} /><QuickRecordClient /></>; }

import { FileText } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { RecordComposer } from "@/components/records/record-composer";

export default function CustomRecordPage() { return <><PageHeader eyebrow="Novo registro" title="Registro personalizado" description="Use texto livre quando nenhuma opção existente atender à necessidade." icon={FileText} /><RecordComposer mode="custom" /></>; }

import { ClipboardPenLine } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { RecordComposer } from "@/components/records/record-composer";

export default function IndividualRecordPage() { return <><PageHeader eyebrow="Novo registro" title="Registro individual" description="Registre uma anotação para um aluno." icon={ClipboardPenLine} /><RecordComposer /></>; }

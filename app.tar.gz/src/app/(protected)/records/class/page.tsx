import { School } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { RecordComposer } from "@/components/records/record-composer";

export default function ClassRecordPage() { return <><PageHeader eyebrow="Novo registro" title="Registro para toda a turma" description="O sistema criará um registro individual para cada aluno matriculado neste momento." icon={School} /><RecordComposer mode="class" /></>; }

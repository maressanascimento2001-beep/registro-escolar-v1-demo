import Link from "next/link";
import { Plus } from "lucide-react";
import { DashboardClient } from "@/components/dashboard/dashboard-client";

export default function DashboardPage() { return <div className="dashboard-page"><div className="page-header"><div><p className="eyebrow">Visão geral</p><h1>Bom dia, Professora <span className="title-sparkle">✦</span></h1><p className="page-description">Acompanhe o que está acontecendo nas suas turmas.</p></div><div className="page-actions"><Link href="/records/individual" className="button button-primary"><Plus size={16} />Novo registro</Link></div></div><DashboardClient /></div>; }

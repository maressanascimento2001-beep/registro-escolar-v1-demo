import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { currentUser, errorResponse } from "@/lib/server";

export async function GET(request: Request) {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  const q = new URL(request.url).searchParams.get("q")?.trim() ?? "";
  if (q.length < 2) return NextResponse.json({ students: [], classes: [], records: [] });
  const [students, classes, records] = await Promise.all([prisma.student.findMany({ where: { active: true, fullName: { contains: q, mode: "insensitive" }, enrollments: { some: { class: { academicYear: { institutionId: user.institutionId } } } } }, take: 8, include: { enrollments: { where: { endedAt: null }, take: 1, include: { class: true } } } }), prisma.schoolClass.findMany({ where: { active: true, name: { contains: q, mode: "insensitive" }, academicYear: { institutionId: user.institutionId } }, take: 8, include: { academicYear: true, discipline: true } }), prisma.record.findMany({ where: { observations: { contains: q, mode: "insensitive" }, class: { academicYear: { institutionId: user.institutionId } } }, take: 8, include: { student: true, category: true, recordType: true } })]);
  return NextResponse.json({ students, classes, records });
}

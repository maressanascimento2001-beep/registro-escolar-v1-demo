import { NextResponse } from "next/server";
import { currentUser, errorResponse } from "@/lib/server";

function extractPdfText(buffer: Buffer) {
  const raw = buffer.toString("latin1");
  const textObjects = [...raw.matchAll(/\(([^()]*)\)\s*Tj/g)].map((match) => match[1]);
  const arrayObjects = [...raw.matchAll(/\[([^\]]+)\]\s*TJ/g)].flatMap((match) => [...match[1].matchAll(/\(([^()]*)\)/g)].map((part) => part[1]));
  return [...textObjects, ...arrayObjects].join("\n").replaceAll("\\(", "(").replaceAll("\\)", ")");
}

export async function POST(request: Request) {
  if (!(await currentUser())) return errorResponse("Não autenticado", 401);
  const form = await request.formData(); const file = form.get("file");
  if (!(file instanceof File) || file.type !== "application/pdf") return errorResponse("Envie um arquivo PDF válido.");
  if (file.size > 10 * 1024 * 1024) return errorResponse("O PDF deve ter no máximo 10 MB.");
  const buffer = Buffer.from(await file.arrayBuffer()); const text = extractPdfText(buffer);
  if (!text.trim()) return errorResponse("Não foi possível extrair texto deste PDF. Use um PDF textual simples ou cadastre os alunos manualmente.");
  const students = text.split(/\r?\n/).map((line) => line.replace(/[|]+/g, " ").replace(/\s+/g, " ").trim()).filter((line) => line.length >= 3 && line.length <= 120 && !/^(nome|aluno|lista|turma|ano|nº|número|matrícula)/i.test(line) && !/^\d+$/.test(line)).map((line) => { const match = line.match(/^(\d{1,3})[\s.)-]+(.+)$/); return { callNumber: match ? Number(match[1]) : null, fullName: (match?.[2] ?? line).trim() }; }).filter((item, index, all) => all.findIndex((other) => other.fullName.toLocaleLowerCase() === item.fullName.toLocaleLowerCase()) === index);
  return NextResponse.json({ originalName: file.name, text, students });
}

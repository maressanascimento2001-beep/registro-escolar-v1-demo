import { NextResponse } from "next/server";

import { extractStudentsFromPdf } from "@/lib/student-import";
import { currentUser, errorResponse } from "@/lib/server";

export async function POST(request: Request) {
  if (!(await currentUser())) return errorResponse("Não autenticado", 401);
  const form = await request.formData();
  const file = form.get("file");
  if (!(file instanceof File) || file.type !== "application/pdf") return errorResponse("Envie um arquivo PDF válido.");
  if (file.size > 10 * 1024 * 1024) return errorResponse("O PDF deve ter no máximo 10 MB.");

  try {
    const buffer = Buffer.from(await file.arrayBuffer());
    const { text, students } = await extractStudentsFromPdf(buffer);
    if (!students.length) return errorResponse("Não foi possível identificar alunos neste PDF. Para listas digitalizadas, aguarde a leitura automática ou cadastre os alunos manualmente.");
    return NextResponse.json({ originalName: file.name, text, students });
  } catch (error) {
    console.error("student_pdf_import_failed", error);
    return errorResponse("Não foi possível ler este PDF. Verifique se o arquivo está íntegro e tente novamente.");
  }
}

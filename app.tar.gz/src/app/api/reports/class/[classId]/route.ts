import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";
import { createPdfReport } from "@/lib/pdf-report";
import { currentUser, errorResponse } from "@/lib/server";

export async function GET(request: Request, { params }: { params: Promise<{ classId: string }> }) {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  const { classId } = await params;
  const url = new URL(request.url);
  const studentIds = url.searchParams.get("studentIds")?.split(",").filter(Boolean);
  const categoryId = url.searchParams.get("categoryId");
  const recordTypeId = url.searchParams.get("recordTypeId");
  const from = url.searchParams.get("from");
  const to = url.searchParams.get("to");
  const sortBy = url.searchParams.get("sortBy") === "CATEGORY" ? "CATEGORY" : "DATE";
  const recordWhere = { classId, ...(categoryId ? { categoryId } : {}), ...(recordTypeId ? { recordTypeId } : {}), ...(from || to ? { recordedAt: { ...(from ? { gte: new Date(from) } : {}), ...(to ? { lte: new Date(`${to}T23:59:59`) } : {}) } } : {}) };
  const schoolClass = await prisma.schoolClass.findFirst({
    where: { id: classId, academicYear: { institutionId: user.institutionId } },
    include: {
      academicYear: true,
      discipline: true,
      enrollments: { where: { endedAt: null, student: { active: true, ...(studentIds?.length ? { id: { in: studentIds } } : {}) } }, orderBy: [{ callNumber: "asc" }, { student: { fullName: "asc" } }], include: { student: { include: { records: { where: recordWhere, include: { category: true, recordType: true }, orderBy: sortBy === "CATEGORY" ? [{ category: { name: "asc" } }, { recordedAt: "desc" }] : { recordedAt: "desc" } } } } } },
    },
  });
  if (!schoolClass) return errorResponse("Turma não encontrada.", 404);
  const period = `${from ?? "Todos"} — ${to ?? "os registros"}`;
  const bytes = await createPdfReport(schoolClass.enrollments.map((enrollment) => ({ fullName: enrollment.student.fullName, callNumber: enrollment.callNumber, className: schoolClass.name, academicYear: schoolClass.academicYear.name, discipline: schoolClass.discipline?.name ?? "", records: enrollment.student.records })), period);
  return new NextResponse(bytes as BodyInit, { headers: { "Content-Type": "application/pdf", "Content-Disposition": `attachment; filename="relatorios-${schoolClass.name.toLowerCase().replaceAll("º ", "-").replaceAll(" ", "-")}-${schoolClass.academicYear.name}.pdf"` } });
}

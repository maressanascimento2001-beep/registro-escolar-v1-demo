import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";
import { createDocReport } from "@/lib/doc-report";
import { createPdfReport, formatReportPeriod } from "@/lib/pdf-report";
import { currentUser, errorResponse } from "@/lib/server";

export async function GET(request: Request, { params }: { params: Promise<{ studentId: string }> }) {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  const { studentId } = await params;
  const url = new URL(request.url);
  const categoryId = url.searchParams.get("categoryId");
  const recordTypeId = url.searchParams.get("recordTypeId");
  const from = url.searchParams.get("from");
  const to = url.searchParams.get("to");
  const sortBy = url.searchParams.get("sortBy") === "CATEGORY" ? "CATEGORY" : "DATE";
  const format = url.searchParams.get("format") === "DOC" ? "DOC" : "PDF";
  const recordWhere = { ...(categoryId ? { categoryId } : {}), ...(recordTypeId ? { recordTypeId } : {}), ...(from || to ? { recordedAt: { ...(from ? { gte: new Date(from) } : {}), ...(to ? { lte: new Date(`${to}T23:59:59`) } : {}) } } : {}) };
  const student = await prisma.student.findFirst({
    where: { id: studentId, enrollments: { some: { class: { academicYear: { institutionId: user.institutionId } } } } },
    include: {
      enrollments: { where: { endedAt: null }, take: 1, include: { class: { include: { academicYear: true, discipline: true } } } },
      records: { where: recordWhere, include: { category: true, recordType: true }, orderBy: sortBy === "CATEGORY" ? [{ category: { name: "asc" } }, { recordedAt: "desc" }] : { recordedAt: "desc" } },
    },
  });
  if (!student || !student.enrollments[0]) return errorResponse("Aluno não encontrado.", 404);
  const enrollment = student.enrollments[0];
  const period = formatReportPeriod(from, to);
  const report = [{ fullName: student.fullName, className: enrollment.class.name, academicYear: enrollment.class.academicYear.name, discipline: enrollment.class.discipline?.name ?? "", records: student.records }];
  const fileName = `relatorio-${student.fullName.toLowerCase().replaceAll(" ", "-")}`;
  if (format === "DOC") {
    const bytes = createDocReport(report, period);
    return new NextResponse(bytes as BodyInit, { headers: { "Content-Type": "application/msword; charset=utf-8", "Content-Disposition": `attachment; filename="${fileName}.doc"` } });
  }
  const bytes = await createPdfReport(report, period);
  return new NextResponse(bytes as BodyInit, { headers: { "Content-Type": "application/pdf", "Content-Disposition": `attachment; filename="${fileName}.pdf"` } });
}

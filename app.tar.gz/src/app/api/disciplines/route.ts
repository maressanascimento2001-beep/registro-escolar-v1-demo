import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { currentUser, errorResponse } from "@/lib/server";

export async function GET() {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  return NextResponse.json(await prisma.discipline.findMany({ where: { institutionId: user.institutionId }, orderBy: { name: "asc" } }));
}

export async function POST(request: Request) {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  const name = String((await request.json()).name ?? "").trim();
  if (!name) return errorResponse("Informe o nome da disciplina.");
  try { return NextResponse.json(await prisma.discipline.create({ data: { institutionId: user.institutionId, name } }), { status: 201 }); } catch { return errorResponse("Esta disciplina já existe.", 409); }
}

import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { currentUser, errorResponse } from "@/lib/server";

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  const { id } = await params;
  const body = await request.json();
  const discipline = await prisma.discipline.findFirst({ where: { id, institutionId: user.institutionId } });
  if (!discipline) return errorResponse("Disciplina não encontrada.", 404);
  return NextResponse.json(await prisma.discipline.update({ where: { id }, data: { name: body.name?.trim() || discipline.name, active: typeof body.active === "boolean" ? body.active : discipline.active } }));
}

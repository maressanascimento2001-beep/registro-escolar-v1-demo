import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { currentUser } from "@/lib/server";

export async function GET() {
  if (!(await currentUser())) return NextResponse.json({ error: "Não autenticado" }, { status: 401 });
  const categories = await prisma.recordCategory.findMany({ orderBy: { name: "asc" }, include: { types: { where: { active: true }, orderBy: { name: "asc" } } } });
  return NextResponse.json({ categories });
}

import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { currentUser, errorResponse } from "@/lib/server";
import { startOfBrazilDay, startOfBrazilMonth } from "@/lib/timezone";

export async function GET() {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  const today = startOfBrazilDay() ?? new Date();
  const month = startOfBrazilMonth() ?? today;
  const where = { class: { academicYear: { institutionId: user.institutionId } } };
  const [classes, students, todayRecords, monthRecords, recentRecords] = await Promise.all([prisma.schoolClass.count({ where: { active: true, academicYear: { institutionId: user.institutionId } } }), prisma.enrollment.count({ where: { endedAt: null, student: { active: true }, class: { active: true, academicYear: { institutionId: user.institutionId } } } }), prisma.record.count({ where: { ...where, recordedAt: { gte: today } } }), prisma.record.count({ where: { ...where, recordedAt: { gte: month } } }), prisma.record.findMany({ where, orderBy: { recordedAt: "desc" }, take: 8, include: { category: true, recordType: true, student: true, class: true } })]);
  return NextResponse.json({ classes, students, todayRecords, monthRecords, recentRecords });
}

import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { currentUser, errorResponse } from "@/lib/server";

export async function GET() {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const month = new Date(); month.setDate(1); month.setHours(0, 0, 0, 0);
  const where = { class: { academicYear: { institutionId: user.institutionId } } };
  const [classes, students, todayRecords, monthRecords, recentRecords] = await Promise.all([prisma.schoolClass.count({ where: { active: true, academicYear: { institutionId: user.institutionId } } }), prisma.enrollment.count({ where: { endedAt: null, student: { active: true }, class: { active: true, academicYear: { institutionId: user.institutionId } } } }), prisma.record.count({ where: { ...where, recordedAt: { gte: today } } }), prisma.record.count({ where: { ...where, recordedAt: { gte: month } } }), prisma.record.findMany({ where, orderBy: { recordedAt: "desc" }, take: 8, include: { category: true, recordType: true, student: true, class: true } })]);
  return NextResponse.json({ classes, students, todayRecords, monthRecords, recentRecords });
}

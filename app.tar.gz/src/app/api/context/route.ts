import { NextResponse } from "next/server";
import { currentUser } from "@/lib/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const user = await currentUser();
  if (!user) return NextResponse.json({ error: "Não autenticado" }, { status: 401 });
  const [academicYears, disciplines, favorites] = await Promise.all([
    prisma.academicYear.findMany({ where: { institutionId: user.institutionId }, orderBy: { name: "desc" }, include: { classes: { where: { active: true }, orderBy: { name: "asc" }, include: { discipline: true, _count: { select: { enrollments: true } } } } } }),
    prisma.discipline.findMany({ where: { institutionId: user.institutionId, active: true }, orderBy: { name: "asc" } }),
    prisma.userFavoriteRecordType.findMany({ where: { userId: user.id }, orderBy: { position: "asc" }, include: { recordType: { include: { category: true } } } }),
  ]);
  return NextResponse.json({ academicYears, disciplines, favorites });
}

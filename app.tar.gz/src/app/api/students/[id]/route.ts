import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { currentUser, errorResponse } from "@/lib/server";

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  const { id } = await params;
  const student = await prisma.student.findFirst({ where: { id, enrollments: { some: { class: { academicYear: { institutionId: user.institutionId } } } } }, include: { enrollments: { where: { endedAt: null }, include: { class: { include: { academicYear: true, discipline: true } } } }, records: { orderBy: { recordedAt: "desc" }, take: 50, include: { category: true, recordType: true, class: true, createdBy: true } } } });
  if (!student) return errorResponse("Aluno não encontrado.", 404);
  return NextResponse.json(student);
}

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  const { id } = await params;
  const student = await prisma.student.findFirst({ where: { id, enrollments: { some: { class: { academicYear: { institutionId: user.institutionId } } } } }, include: { enrollments: { where: { endedAt: null } } } });
  if (!student) return errorResponse("Aluno não encontrado.", 404);
  const body = await request.json();
  const fullName = String(body.fullName ?? student.fullName).trim();
  const callNumber = body.callNumber === "" || body.callNumber == null ? null : Number(body.callNumber);
  const enrollment = student.enrollments[0];
  if (enrollment && callNumber !== null && await prisma.enrollment.findFirst({ where: { classId: enrollment.classId, callNumber, endedAt: null, id: { not: enrollment.id } } })) return errorResponse("Este número de chamada já está em uso nesta turma.", 409);
  const updated = await prisma.$transaction(async (tx) => { const nextStudent = await tx.student.update({ where: { id }, data: { fullName, active: body.active ?? student.active } }); if (enrollment) await tx.enrollment.update({ where: { id: enrollment.id }, data: { callNumber } }); return nextStudent; });
  return NextResponse.json(updated);
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  const { id } = await params;
  const student = await prisma.student.findFirst({ where: { id, enrollments: { some: { class: { academicYear: { institutionId: user.institutionId } } } } } });
  if (!student) return errorResponse("Aluno não encontrado.", 404);
  await prisma.student.update({ where: { id }, data: { active: false } });
  await prisma.enrollment.updateMany({ where: { studentId: id, endedAt: null }, data: { endedAt: new Date() } });
  return NextResponse.json({ ok: true });
}

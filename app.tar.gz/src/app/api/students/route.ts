import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { currentUser, errorResponse } from "@/lib/server";

export async function GET(request: Request) {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  const { searchParams } = new URL(request.url);
  const classId = searchParams.get("classId");
  const q = searchParams.get("q") ?? "";
  const students = await prisma.enrollment.findMany({ where: { ...(classId ? { classId } : {}), endedAt: null, class: { active: true, academicYear: { institutionId: user.institutionId } }, student: { active: true, fullName: { contains: q, mode: "insensitive" } } }, orderBy: [{ callNumber: "asc" }, { student: { fullName: "asc" } }], include: { student: true, class: { include: { academicYear: true, discipline: true } } } });
  return NextResponse.json(students);
}

export async function POST(request: Request) {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  const body = await request.json();
  const fullName = String(body.fullName ?? "").trim();
  const classId = String(body.classId ?? "");
  if (!fullName || !classId) return errorResponse("Informe o nome e a turma.");
  const schoolClass = await prisma.schoolClass.findFirst({ where: { id: classId, academicYear: { institutionId: user.institutionId } } });
  if (!schoolClass) return errorResponse("Turma inválida.");
  const callNumber = body.callNumber === "" || body.callNumber == null ? null : Number(body.callNumber);
  if (callNumber !== null && await prisma.enrollment.findFirst({ where: { classId, callNumber, endedAt: null } })) return errorResponse("Este número de chamada já está em uso nesta turma.", 409);
  const student = await prisma.student.create({ data: { fullName } });
  const enrollment = await prisma.enrollment.create({ data: { academicYearId: schoolClass.academicYearId, classId, studentId: student.id, callNumber } });
  return NextResponse.json({ student, enrollment }, { status: 201 });
}

import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { currentUser, errorResponse } from "@/lib/server";

export async function GET(request: Request) {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  const { searchParams } = new URL(request.url);
  const academicYearId = searchParams.get("academicYearId");
  const q = searchParams.get("q") ?? "";
  const classes = await prisma.schoolClass.findMany({ where: { active: true, academicYear: { institutionId: user.institutionId, ...(academicYearId ? { id: academicYearId } : {}) }, name: { contains: q, mode: "insensitive" } }, orderBy: { name: "asc" }, include: { academicYear: true, discipline: true, _count: { select: { enrollments: true, records: true } } } });
  return NextResponse.json(classes);
}

export async function POST(request: Request) {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  const body = await request.json();
  const academicYearId = String(body.academicYearId ?? "");
  const name = String(body.name ?? "").trim();
  if (!academicYearId || !name) return errorResponse("Informe o ano letivo e o nome da turma.");
  const year = await prisma.academicYear.findFirst({ where: { id: academicYearId, institutionId: user.institutionId } });
  if (!year) return errorResponse("Ano letivo inválido.");
  try { return NextResponse.json(await prisma.schoolClass.create({ data: { academicYearId, name, gradeLevel: body.gradeLevel || null, shift: body.shift || null, disciplineId: body.disciplineId || null } }), { status: 201 }); } catch { return errorResponse("Já existe uma turma com esse nome neste ano letivo.", 409); }
}

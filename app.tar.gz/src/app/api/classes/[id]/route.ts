import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { currentUser, errorResponse } from "@/lib/server";

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  const { id } = await params;
  const item = await prisma.schoolClass.findFirst({ where: { id, academicYear: { institutionId: user.institutionId } }, include: { academicYear: true, discipline: true, enrollments: { where: { endedAt: null, student: { active: true } }, orderBy: [{ callNumber: "asc" }, { student: { fullName: "asc" } }], include: { student: true } }, _count: { select: { records: true } } } });
  if (!item) return errorResponse("Turma não encontrada.", 404);
  return NextResponse.json(item);
}

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  const { id } = await params;
  const current = await prisma.schoolClass.findFirst({ where: { id, academicYear: { institutionId: user.institutionId } } });
  if (!current) return errorResponse("Turma não encontrada.", 404);
  const body = await request.json();
  return NextResponse.json(await prisma.schoolClass.update({ where: { id }, data: { name: body.name?.trim() || current.name, gradeLevel: body.gradeLevel ?? current.gradeLevel, shift: body.shift ?? current.shift, disciplineId: body.disciplineId ?? current.disciplineId } }));
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  const { id } = await params;
  const current = await prisma.schoolClass.findFirst({ where: { id, academicYear: { institutionId: user.institutionId } }, include: { _count: { select: { enrollments: true, records: true } } } });
  if (!current) return errorResponse("Turma não encontrada.", 404);
  const archivedAt = new Date();
  await prisma.$transaction([
    prisma.schoolClass.update({ where: { id }, data: { active: false, archivedAt } }),
    prisma.enrollment.updateMany({ where: { classId: id, endedAt: null }, data: { endedAt: archivedAt } }),
  ]);
  return NextResponse.json({ ok: true });
}

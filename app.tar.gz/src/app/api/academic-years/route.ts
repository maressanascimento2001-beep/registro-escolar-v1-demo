import { NextResponse } from "next/server";
import { currentUser, errorResponse } from "@/lib/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  return NextResponse.json(await prisma.academicYear.findMany({ where: { institutionId: user.institutionId }, orderBy: { name: "desc" }, include: { _count: { select: { classes: true } } } }));
}

export async function POST(request: Request) {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  const body = await request.json();
  const name = String(body.name ?? "").trim();
  if (!name) return errorResponse("Informe o ano letivo.");
  const exists = await prisma.academicYear.findUnique({ where: { institutionId_name: { institutionId: user.institutionId, name } } });
  if (exists) return errorResponse("Este ano letivo já existe.", 409);
  const academicYear = await prisma.academicYear.create({ data: { institutionId: user.institutionId, name, identification: body.identification || null, startsAt: body.startsAt ? new Date(body.startsAt) : null, endsAt: body.endsAt ? new Date(body.endsAt) : null } });
  return NextResponse.json(academicYear, { status: 201 });
}

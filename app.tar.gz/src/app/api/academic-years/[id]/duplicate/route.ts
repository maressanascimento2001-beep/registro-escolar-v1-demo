import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { currentUser, errorResponse } from "@/lib/server";
import { parseBrazilDateBoundary } from "@/lib/timezone";

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  const { id } = await params;
  const body = await request.json();
  const name = String(body.name ?? "").trim();
  if (!name) return errorResponse("Informe o novo ano letivo.");
  const source = await prisma.academicYear.findFirst({ where: { id, institutionId: user.institutionId }, include: { classes: true } });
  if (!source) return errorResponse("Ano letivo de origem não encontrado.", 404);
  const exists = await prisma.academicYear.findUnique({ where: { institutionId_name: { institutionId: user.institutionId, name } } });
  if (exists) return errorResponse("O novo ano letivo já existe.", 409);
  const startsAt = body.startsAt ? parseBrazilDateBoundary(body.startsAt) : null;
  const endsAt = body.endsAt ? parseBrazilDateBoundary(body.endsAt, true) : null;
  if ((body.startsAt && !startsAt) || (body.endsAt && !endsAt)) return errorResponse("Informe datas válidas para o ano letivo.");
  const result = await prisma.$transaction(async (tx) => {
    const year = await tx.academicYear.create({ data: { institutionId: user.institutionId, name, identification: body.identification || null, startsAt, endsAt } });
    for (const item of source.classes) await tx.schoolClass.create({ data: { academicYearId: year.id, name: item.name, gradeLevel: item.gradeLevel, shift: item.shift, disciplineId: item.disciplineId } });
    return year;
  });
  return NextResponse.json({ academicYear: result, classesCopied: source.classes.length }, { status: 201 });
}

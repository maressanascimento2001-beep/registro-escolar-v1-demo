import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { currentUser, errorResponse } from "@/lib/server";

export async function GET() { const user = await currentUser(); if (!user) return errorResponse("Não autenticado", 401); return NextResponse.json(await prisma.userFavoriteRecordType.findMany({ where: { userId: user.id }, orderBy: { position: "asc" }, include: { recordType: { include: { category: true } } } })); }

export async function PUT(request: Request) {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  const ids = (await request.json()).recordTypeIds;
  if (!Array.isArray(ids)) return errorResponse("Informe os tipos favoritos.");
  await prisma.$transaction(async (tx) => { await tx.userFavoriteRecordType.deleteMany({ where: { userId: user.id } }); for (const [position, recordTypeId] of ids.entries()) await tx.userFavoriteRecordType.create({ data: { userId: user.id, recordTypeId, position } }); });
  return NextResponse.json({ ok: true });
}

import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { currentUser, errorResponse, parseDate } from "@/lib/server";

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  const { id } = await params;
  const record = await prisma.record.findFirst({ where: { id, class: { academicYear: { institutionId: user.institutionId } } }, include: { category: true, recordType: true, student: true, class: { include: { academicYear: true, discipline: true } } } });
  if (!record) return errorResponse("Registro não encontrado.", 404);
  return NextResponse.json(record);
}

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  const { id } = await params;
  const current = await prisma.record.findFirst({ where: { id, class: { academicYear: { institutionId: user.institutionId } } } });
  if (!current) return errorResponse("Registro não encontrado.", 404);
  const body = await request.json();
  const categoryId = body.categoryId ?? current.categoryId;
  const recordTypeId = body.recordTypeId ?? current.recordTypeId;
  const type = recordTypeId ? await prisma.recordType.findFirst({ where: { id: recordTypeId, categoryId, active: true } }) : null;
  if (!type) return errorResponse("O tipo selecionado não pertence à categoria.");
  const category = await prisma.recordCategory.findUnique({ where: { id: categoryId } });
  const observations = body.observations ?? current.observations;
  if (category?.name === "Outros" && !String(observations ?? "").trim()) return errorResponse("A descrição é obrigatória para a categoria Outros.");
  const recordedAt = body.recordedAt ? parseDate(body.recordedAt) : current.recordedAt;
  if (!recordedAt) return errorResponse("Informe uma data válida.");
  return NextResponse.json(await prisma.record.update({ where: { id }, data: { categoryId, recordTypeId, observations: observations || null, customText: category?.name === "Outros" ? observations : null, recordedAt } }));
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  const { id } = await params;
  const current = await prisma.record.findFirst({ where: { id, class: { academicYear: { institutionId: user.institutionId } } } });
  if (!current) return errorResponse("Registro não encontrado.", 404);
  await prisma.record.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}

import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { contextClass, currentUser, errorResponse, parseDate } from "@/lib/server";

export async function GET(request: Request) {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  const { searchParams } = new URL(request.url);
  const studentId = searchParams.get("studentId");
  const classId = searchParams.get("classId");
  const categoryId = searchParams.get("categoryId");
  const recordTypeId = searchParams.get("recordTypeId");
  const from = searchParams.get("from");
  const to = searchParams.get("to");
  const records = await prisma.record.findMany({ where: { ...(studentId ? { studentId } : {}), ...(classId ? { classId } : {}), ...(categoryId ? { categoryId } : {}), ...(recordTypeId ? { recordTypeId } : {}), ...(from || to ? { recordedAt: { ...(from ? { gte: new Date(from) } : {}), ...(to ? { lte: new Date(`${to}T23:59:59`) } : {}) } } : {}), class: { academicYear: { institutionId: user.institutionId } } }, orderBy: { recordedAt: "desc" }, include: { category: true, recordType: true, student: true, class: { include: { academicYear: true, discipline: true } }, createdBy: true } });
  return NextResponse.json(records);
}

export async function POST(request: Request) {
  const user = await currentUser();
  if (!user) return errorResponse("Não autenticado", 401);
  const body = await request.json();
  const academicYearId = String(body.academicYearId ?? "");
  const classId = String(body.classId ?? "");
  const categoryId = String(body.categoryId ?? "");
  const recordTypeId = String(body.recordTypeId ?? "");
  const schoolClass = await contextClass(classId, academicYearId, user.institutionId);
  if (!schoolClass) return errorResponse("A turma não pertence ao ano letivo selecionado.");
  const category = await prisma.recordCategory.findUnique({ where: { id: categoryId } });
  const recordType = await prisma.recordType.findFirst({ where: { id: recordTypeId, categoryId, active: true } });
  if (!category || !recordType) return errorResponse("Categoria ou tipo de registro inválido.");
  const observations = String(body.observations ?? "").trim();
  if (category.name === "Outros" && !observations) return errorResponse("A descrição é obrigatória para a categoria Outros.");
  const date = parseDate(body.recordedAt);
  if (!date) return errorResponse("Informe uma data válida.");
  const enrollments = await prisma.enrollment.findMany({ where: { classId, academicYearId, endedAt: null, student: { active: true, ...(body.applyToClass ? {} : { id: { in: Array.isArray(body.studentIds) ? body.studentIds : [] } }) } } });
  if (!enrollments.length) return errorResponse("Selecione pelo menos um aluno ativo.");
  const scopeMode = body.applyToClass ? "CLASS" : enrollments.length > 1 ? "MULTIPLE" : "SINGLE";
  const records = await prisma.$transaction(enrollments.map((enrollment) => prisma.record.create({ data: { academicYearId, classId, studentId: enrollment.studentId, categoryId, recordTypeId, observations: observations || null, customText: category.name === "Outros" ? observations : null, recordedAt: date, entryMode: body.entryMode === "QUICK" ? "QUICK" : "NORMAL", scopeMode, createdById: user.id }, include: { category: true, recordType: true, student: true } })));
  return NextResponse.json({ count: records.length, records }, { status: 201 });
}

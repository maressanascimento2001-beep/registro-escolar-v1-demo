"use client";

import { FormEvent, useState } from "react";
import { signIn } from "next-auth/react";
import { ArrowRight, BookOpen, LockKeyhole, Mail } from "lucide-react";

export default function LoginPage() {
  const [error, setError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setIsSubmitting(true);

    const formData = new FormData(event.currentTarget);
    const result = await signIn("credentials", {
      email: formData.get("email"),
      password: formData.get("password"),
      redirect: false,
      callbackUrl: "/dashboard",
    });

    if (result?.error) {
      setError("Confira os dados informados e tente novamente.");
      setIsSubmitting(false);
      return;
    }

    window.location.assign(result?.url ?? "/dashboard");
  }

  return (
    <main className="login-page">
      <section className="login-aside">
        <div className="brand-mark brand-mark-light"><BookOpen size={20} strokeWidth={2.4} /></div>
        <p className="eyebrow eyebrow-light">Registro Escolar</p>
        <h1>Registre o que importa, com leveza.</h1>
        <p className="login-aside-copy">Uma experiência simples para acompanhar turmas, alunos e registros ao longo do ano letivo.</p>
        <div className="login-quote"><span>“</span><p>Organização para a rotina. Clareza para cada história.</p></div>
      </section>

      <section className="login-panel">
        <div className="login-card">
          <div className="login-card-heading">
            <p className="eyebrow">Bem-vindo de volta</p>
            <h2>Entrar na sua conta</h2>
            <p>Use suas credenciais para acessar o Registro Escolar.</p>
          </div>

          <form onSubmit={handleSubmit} className="form-stack">
            <label className="field-label" htmlFor="email">E-mail</label>
            <div className="input-with-icon"><Mail size={17} /><input id="email" name="email" type="email" placeholder="professor@escola.com" required /></div>
            <label className="field-label" htmlFor="password">Senha</label>
            <div className="input-with-icon"><LockKeyhole size={17} /><input id="password" name="password" type="password" placeholder="Digite sua senha" required /></div>
            {error ? <p className="form-error" role="alert">{error}</p> : null}
            <button className="button button-primary button-full" type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Entrando..." : "Entrar"}<ArrowRight size={17} />
            </button>
          </form>

          <p className="login-switch">Ainda não possui uma conta? <a href="/register">Criar conta</a></p>
          <p className="login-help">Acesso exclusivo para o perfil Professor.</p>
        </div>
        <p className="login-footer">© 2026 Registro Escolar</p>
      </section>
    </main>
  );
}

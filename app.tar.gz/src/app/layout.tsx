import type { Metadata } from "next";

import "./globals.css";

export const metadata: Metadata = {
  title: "Registro Escolar",
  description: "Registros escolares com leveza, organização e agilidade.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  );
}

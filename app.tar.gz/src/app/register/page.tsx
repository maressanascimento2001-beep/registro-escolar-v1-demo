"use client";

import { FormEvent, useState } from "react";
import { ArrowRight, BookOpen, LockKeyhole, Mail, UserRound } from "lucide-react";
import { signIn } from "next-auth/react";

export default function RegisterPage() {
  const [error, setError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setIsSubmitting(true);
    const formData = new FormData(event.currentTarget);
    const name = String(formData.get("name") ?? "");
    const email = String(formData.get("email") ?? "");
    const password = String(formData.get("password") ?? "");
    const confirmation = String(formData.get("confirmation") ?? "");

    if (password !== confirmation) {
      setError("As senhas não conferem.");
      setIsSubmitting(false);
      return;
    }

    const response = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, password }),
    });
    const data = await response.json().catch(() => null) as { error?: string } | null;
    if (!response.ok) {
      setError(data?.error ?? "Não foi possível criar sua conta.");
      setIsSubmitting(false);
      return;
    }

    const result = await signIn("credentials", { email, password, redirect: false, callbackUrl: "/dashboard" });
    if (result?.error) {
      setError("Conta criada, mas não foi possível iniciar a sessão. Volte ao login.");
      setIsSubmitting(false);
      return;
    }
    window.location.assign(result?.url ?? "/dashboard");
  }

  return (
    <main className="login-page">
      <section className="login-aside">
        <div className="brand-mark brand-mark-light"><BookOpen size={20} strokeWidth={2.4} /></div>
        <p className="eyebrow eyebrow-light">Registro Escolar</p>
        <h1>Crie seu espaço de organização.</h1>
        <p className="login-aside-copy">Tenha uma conta própria para registrar turmas, alunos e acompanhamentos da sua rotina.</p>
        <div className="login-quote"><span>“</span><p>Organização para a rotina. Clareza para cada história.</p></div>
      </section>

      <section className="login-panel">
        <div className="login-card">
          <div className="login-card-heading">
            <p className="eyebrow">Novo acesso</p>
            <h2>Criar conta de Professor</h2>
            <p>Cadastre seus dados para acessar o Registro Escolar.</p>
          </div>

          <form onSubmit={handleSubmit} className="form-stack">
            <label className="field-label" htmlFor="name">Nome completo</label>
            <div className="input-with-icon"><UserRound size={17} /><input id="name" name="name" type="text" placeholder="Seu nome" autoComplete="name" required /></div>
            <label className="field-label" htmlFor="email">E-mail</label>
            <div className="input-with-icon"><Mail size={17} /><input id="email" name="email" type="email" placeholder="voce@escola.com" autoComplete="email" required /></div>
            <label className="field-label" htmlFor="password">Senha</label>
            <div className="input-with-icon"><LockKeyhole size={17} /><input id="password" name="password" type="password" placeholder="Pelo menos 8 caracteres" autoComplete="new-password" minLength={8} required /></div>
            <label className="field-label" htmlFor="confirmation">Confirmar senha</label>
            <div className="input-with-icon"><LockKeyhole size={17} /><input id="confirmation" name="confirmation" type="password" placeholder="Repita sua senha" autoComplete="new-password" minLength={8} required /></div>
            {error ? <p className="form-error" role="alert">{error}</p> : null}
            <button className="button button-primary button-full" type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Criando conta..." : "Criar conta"}<ArrowRight size={17} />
            </button>
          </form>

          <p className="login-switch">Já possui uma conta? <a href="/login">Entrar</a></p>
          <p className="login-help">Todas as contas usam o perfil Professor.</p>
        </div>
        <p className="login-footer">© 2026 Registro Escolar</p>
      </section>
    </main>
  );
}

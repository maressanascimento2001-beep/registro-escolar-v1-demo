"use client";

import Link from "next/link";
import { Edit3, Eye, Trash2, Users } from "lucide-react";
import { useEffect, useState } from "react";
import { useWorkContext } from "@/components/context/use-context";

type SchoolClass = { id: string; name: string; gradeLevel: string | null; shift: string | null; discipline: { name: string } | null; academicYear: { name: string }; _count: { enrollments: number; records: number } };

export function ClassListClient() {
  const context = useWorkContext(); const [items, setItems] = useState<SchoolClass[]>([]); const [q, setQ] = useState(""); const [error, setError] = useState("");
  async function load() { const params = new URLSearchParams(); if (context.academicYearId) params.set("academicYearId", context.academicYearId); if (q) params.set("q", q); const response = await fetch(`/api/classes?${params}`); if (response.ok) setItems(await response.json()); else setError("Não foi possível carregar as turmas."); }
  useEffect(() => { load().catch(() => setError("Não foi possível carregar as turmas.")); }, [context.academicYearId]);
  return <><div className="filter-bar"><div className="search-field"><input value={q} onChange={(event) => setQ(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") load(); }} placeholder="Pesquisar turma..." /></div><button className="button button-light" type="button" onClick={() => load()}>Pesquisar</button></div>{error ? <div className="warning-box" style={{ marginBottom: 16 }}>{error}</div> : null}<div className="data-card"><table className="data-table"><thead><tr><th>Turma</th><th>Ano / etapa</th><th>Turno</th><th>Disciplina</th><th>Alunos</th><th /></tr></thead><tbody>{items.map((item) => <tr key={item.id}><td><strong>{item.name}</strong><small className="table-secondary">{item.academicYear.name}</small></td><td>{item.gradeLevel ?? "—"}</td><td>{item.shift ?? "—"}</td><td>{item.discipline?.name ?? "Sem disciplina"}</td><td><span className="badge badge-lilac"><Users size={12} style={{ marginRight: 4 }} />{item._count.enrollments}</span></td><td><div className="table-actions"><Link className="table-action" href={`/classes/${item.id}`}><Eye size={15} /></Link><Link className="table-action" href={`/classes/${item.id}/edit`}><Edit3 size={15} /></Link><button className="table-action" type="button" title="Arquivar" onClick={async () => { if (confirm("Arquivar esta turma?")) { const response = await fetch(`/api/classes/${item.id}`, { method: "DELETE" }); if (response.ok) load(); else setError((await response.json()).error); } }}><Trash2 size={15} /></button></div></td></tr>)}{!items.length ? <tr><td colSpan={6}><div className="table-empty">Nenhuma turma encontrada para o contexto atual.</div></td></tr> : null}</tbody></table></div></>;
}

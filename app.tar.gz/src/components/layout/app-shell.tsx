"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut } from "next-auth/react";
import {
  BarChart3,
  BookOpen,
  ChevronDown,
  ClipboardPenLine,
  GraduationCap,
  LayoutDashboard,
  Menu,
  Search,
  Settings,
  Sparkles,
  Users,
  X,
} from "lucide-react";
import { useState } from "react";
import { ContextControls } from "@/components/context/context-controls";

const navigation = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/classes", label: "Turmas", icon: Users },
  { href: "/students", label: "Alunos", icon: GraduationCap },
  { href: "/records/individual", label: "Registros", icon: ClipboardPenLine },
  { href: "/reports/filters", label: "Relatórios", icon: BarChart3 },
  { href: "/settings/academic-years", label: "Configurações", icon: Settings },
];

export function AppShell({ children }: Readonly<{ children: React.ReactNode }>) {
  const pathname = usePathname();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  return (
    <div className="app-shell">
      <div className={`mobile-backdrop ${isSidebarOpen ? "is-visible" : ""}`} onClick={() => setIsSidebarOpen(false)} />
      <aside className={`sidebar ${isSidebarOpen ? "is-open" : ""}`}>
        <div className="sidebar-brand">
          <Link href="/dashboard" className="brand-link" onClick={() => setIsSidebarOpen(false)}>
            <span className="brand-mark"><BookOpen size={18} strokeWidth={2.4} /></span>
            <span><strong>Registro</strong><small>Escolar</small></span>
          </Link>
          <button className="icon-button sidebar-close" aria-label="Fechar menu" onClick={() => setIsSidebarOpen(false)}><X size={19} /></button>
        </div>

        <div className="sidebar-context">
          <p className="sidebar-label">Contexto atual</p>
          <ContextControls compact />
        </div>

        <nav className="sidebar-nav" aria-label="Navegação principal">
          <p className="sidebar-label">Menu principal</p>
          {navigation.map((item) => {
            const Icon = item.icon;
            const isActive = pathname === item.href || (item.href !== "/dashboard" && pathname.startsWith(item.href));
            return <Link key={item.href} href={item.href as never} className={`nav-item ${isActive ? "is-active" : ""}`} onClick={() => setIsSidebarOpen(false)}><Icon size={18} /><span>{item.label}</span>{isActive ? <i className="nav-active-indicator" /> : null}</Link>;
          })}
        </nav>

        <div className="sidebar-bottom">
          <Link href="/records/quick" className="quick-card" onClick={() => setIsSidebarOpen(false)}>
            <span className="quick-card-icon"><Sparkles size={16} /></span>
            <span><strong>Registro Rápido</strong><small>Lance em poucos cliques</small></span>
          </Link>
          <div className="sidebar-user"><div className="avatar avatar-small">PR</div><div><strong>Professora</strong><small>Perfil Professor</small></div><button className="icon-button sidebar-user-more" aria-label="Sair" onClick={() => signOut({ callbackUrl: "/login" })}><ChevronDown size={16} /></button></div>
        </div>
      </aside>

      <div className="app-main">
        <header className="topbar">
          <div className="topbar-left"><button className="icon-button mobile-menu" aria-label="Abrir menu" onClick={() => setIsSidebarOpen(true)}><Menu size={21} /></button><div className="breadcrumb"><span>Registro Escolar</span><span className="breadcrumb-slash">/</span><strong>{getPageLabel(pathname)}</strong></div></div>
          <div className="topbar-actions">
            <Link href="/search" className="global-search"><Search size={17} /><span>Pesquisar aluno ou turma</span><kbd>⌘ K</kbd></Link>
            <div className="topbar-divider" />
            <ContextControls />
            <div className="avatar avatar-top">PR</div>
          </div>
        </header>

        <main className="page-content">{children}</main>
        <footer className="app-footer"><span>Registro Escolar v1.0</span><span>Feito para tornar a rotina mais leve <span className="footer-heart">♡</span></span></footer>
      </div>
    </div>
  );
}

function getPageLabel(pathname: string) {
  if (pathname.startsWith("/classes")) return "Turmas";
  if (pathname.startsWith("/students")) return "Alunos";
  if (pathname.startsWith("/records")) return "Registros";
  if (pathname.startsWith("/reports")) return "Relatórios";
  if (pathname.startsWith("/settings")) return "Configurações";
  if (pathname.startsWith("/search")) return "Pesquisa global";
  return "Dashboard";
}

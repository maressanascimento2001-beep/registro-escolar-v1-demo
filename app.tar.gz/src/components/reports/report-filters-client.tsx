"use client";

import { Download, FileText } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { useWorkContext } from "@/components/context/use-context";

type ClassItem = { id: string; name: string; academicYear: { name: string } };
type StudentItem = { student: { id: string; fullName: string }; callNumber: number | null };
type Category = { id: string; name: string; types: Array<{ id: string; name: string }> };
type FileFormat = "PDF" | "DOC";

export function ReportFiltersClient() {
  const context = useWorkContext();
  const [classes, setClasses] = useState<ClassItem[]>([]);
  const [students, setStudents] = useState<StudentItem[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [classId, setClassId] = useState(context.classId !== "all" ? context.classId : "");
  const [studentId, setStudentId] = useState("");
  const [studentIds, setStudentIds] = useState<string[]>([]);
  const [categoryId, setCategoryId] = useState("");
  const [recordTypeId, setRecordTypeId] = useState("");
  const [mode, setMode] = useState("student");
  const [sortBy, setSortBy] = useState("DATE");
  const [format, setFormat] = useState<FileFormat>("PDF");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [reportPath, setReportPath] = useState("");
  const types = useMemo(() => categories.find((item) => item.id === categoryId)?.types ?? [], [categories, categoryId]);

  useEffect(() => {
    fetch("/api/catalog").then((response) => response.json()).then((data) => setCategories(data.categories ?? [])).catch(() => undefined);
    fetch("/api/classes").then((response) => response.json()).then(setClasses).catch(() => undefined);
  }, []);

  useEffect(() => {
    if (classId) fetch(`/api/students?classId=${encodeURIComponent(classId)}`).then((response) => response.json()).then(setStudents).catch(() => undefined);
    else setStudents([]);
  }, [classId]);

  function generate() {
    const params = new URLSearchParams({ sortBy });
    if (categoryId) params.set("categoryId", categoryId);
    if (recordTypeId) params.set("recordTypeId", recordTypeId);
    if (from) params.set("from", from);
    if (to) params.set("to", to);
    if (mode === "student" && studentId) setReportPath(`/api/reports/student/${studentId}?${params}`);
    else if (classId) {
      if (mode === "batch" && studentIds.length) params.set("studentIds", studentIds.join(","));
      setReportPath(`/api/reports/class/${classId}?${params}`);
    }
  }

  function hrefFor(nextFormat: FileFormat) {
    if (!reportPath) return "";
    return `${reportPath}&format=${nextFormat}`;
  }

  const primaryHref = hrefFor(format);

  return <div className="form-card">
    <div className="form-grid">
      <label className="field"><span>Modo de geração</span><select value={mode} onChange={(event) => { setMode(event.target.value); setReportPath(""); }}><option value="student">Relatório individual</option><option value="batch">Vários alunos selecionados</option><option value="class">Turma inteira</option></select></label>
      <label className="field"><span>Turma</span><select value={classId} onChange={(event) => { setClassId(event.target.value); setStudentId(""); setStudentIds([]); setReportPath(""); }}><option value="">Selecionar turma</option>{classes.map((item) => <option key={item.id} value={item.id}>{item.name} · {item.academicYear.name}</option>)}</select></label>
      {mode === "student" ? <label className="field"><span>Aluno</span><select value={studentId} onChange={(event) => { setStudentId(event.target.value); setReportPath(""); }}><option value="">Selecionar aluno</option>{students.map((item) => <option key={item.student.id} value={item.student.id}>{item.callNumber ?? "—"} · {item.student.fullName}</option>)}</select></label> : null}
      <label className="field"><span>Categoria</span><select value={categoryId} onChange={(event) => { setCategoryId(event.target.value); setRecordTypeId(""); setReportPath(""); }}><option value="">Todas as categorias</option>{categories.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
      <label className="field"><span>Tipo do registro</span><select disabled={!categoryId} value={recordTypeId} onChange={(event) => { setRecordTypeId(event.target.value); setReportPath(""); }}><option value="">{categoryId ? "Todos os tipos" : "Selecione primeiro uma categoria."}</option>{types.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
      <label className="field"><span>Data inicial</span><input type="date" value={from} onChange={(event) => { setFrom(event.target.value); setReportPath(""); }} /></label>
      <label className="field"><span>Data final</span><input type="date" value={to} onChange={(event) => { setTo(event.target.value); setReportPath(""); }} /></label>
      <label className="field"><span>Ordenar por</span><select value={sortBy} onChange={(event) => { setSortBy(event.target.value); setReportPath(""); }}><option value="DATE">Data · mais recentes primeiro</option><option value="CATEGORY">Categoria · alfabética</option></select></label>
      <label className="field"><span>Formato do arquivo</span><select value={format} onChange={(event) => setFormat(event.target.value as FileFormat)}><option value="PDF">PDF · pronto para imprimir</option><option value="DOC">DOC · editável no Word</option></select></label>
    </div>
    {mode === "batch" ? <div className="selection-list" style={{ marginTop: 18 }}>{students.map((item) => <label className={`selection-item ${studentIds.includes(item.student.id) ? "is-selected" : ""}`} key={item.student.id}><input type="checkbox" checked={studentIds.includes(item.student.id)} onChange={() => setStudentIds(studentIds.includes(item.student.id) ? studentIds.filter((id) => id !== item.student.id) : [...studentIds, item.student.id])} /><span>{item.callNumber ?? "—"} · {item.student.fullName}</span></label>)}</div> : null}
    <div className="form-actions"><button className="button button-primary" type="button" onClick={generate}><FileText size={16} />Preparar relatório</button>{reportPath ? <><a className="button button-secondary" href={primaryHref} download><Download size={16} />Baixar {format}</a><a className="button button-light" href={hrefFor(format === "PDF" ? "DOC" : "PDF")} download><Download size={16} />Baixar {format === "PDF" ? "DOC" : "PDF"}</a></> : null}</div>
  </div>;
}

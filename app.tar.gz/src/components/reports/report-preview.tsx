"use client";

import { Download, FileText, Printer } from "lucide-react";

function formatHref(href: string | undefined, format: "PDF" | "DOC") {
  if (!href) return "";
  return `${href}${href.includes("?") ? "&" : "?"}format=${format}`;
}

export function ReportSheet({ title = "Relatório individual", downloadHref }: Readonly<{ title?: string; downloadHref?: string }>) {
  const pdfHref = formatHref(downloadHref, "PDF");
  const docHref = formatHref(downloadHref, "DOC");
  return <div className="report-layout">
    <div className="report-toolbar"><span><FileText size={16} />Pré-visualização · A4</span><div><button className="button button-light" type="button" onClick={() => window.print()}><Printer size={15} />Imprimir</button>{downloadHref ? <><a className="button button-primary" href={pdfHref} download><Download size={15} />Baixar PDF</a><a className="button button-secondary" href={docHref} download><Download size={15} />Baixar DOC</a></> : <button className="button button-primary" type="button" disabled><Download size={15} />Baixar relatório</button>}</div></div>
    <div className="report-paper report-paper-neutral"><div className="report-paper-header"><div><p>RELATÓRIO DE REGISTROS</p><h2>{title}</h2></div><div className="report-meta"><span>Período do filtro</span><strong>01 jun — 30 jun 2026</strong></div></div><div className="report-identity"><div><span>Nome do aluno</span><strong>Ana Souza</strong></div><div><span>Turma</span><strong>5º A</strong></div><div><span>Ano letivo</span><strong>2026</strong></div><div><span>Disciplina</span><strong>Língua Portuguesa</strong></div><div><span>Emitido em</span><strong>18 jun 2026</strong></div></div><table className="report-table"><thead><tr><th>Data</th><th>Categoria</th><th>Tipo do registro</th><th>Observações</th></tr></thead><tbody><tr><td>18 jun 2026</td><td>Elogios</td><td>Excelente participação</td><td>Participou com atenção e contribuiu para a atividade.</td></tr><tr><td>12 jun 2026</td><td>Pedagógico</td><td>Não entregou trabalho</td><td>Trabalho não apresentado na data combinada.</td></tr><tr><td>04 jun 2026</td><td>Avaliações</td><td>Entrega de avaliação</td><td>Avaliação devolvida ao aluno.</td></tr></tbody></table></div>
  </div>;
}

"use client";

import Link from "next/link";
import { CalendarDays, CheckCircle2, Clock3, FileText, School, Sparkles, UserRound, Users } from "lucide-react";
import { FormEvent, useEffect, useState } from "react";
import { useWorkContext } from "@/components/context/use-context";

type Category = { id: string; name: string; types: Array<{ id: string; name: string }> };
type Enrollment = { id: string; callNumber: number | null; student: { id: string; fullName: string } };
type ScopeMode = "individual" | "multiple" | "class";

function initialScope(mode: "individual" | "multiple" | "class" | "custom" | "quick"): ScopeMode {
  if (mode === "class") return "class";
  if (mode === "multiple") return "multiple";
  return "individual";
}

export function RecordComposer({ mode = "individual" }: { mode?: "individual" | "multiple" | "class" | "custom" | "quick" }) {
  const context = useWorkContext();
  const [categories, setCategories] = useState<Category[]>([]);
  const [scopeMode, setScopeMode] = useState<ScopeMode>(() => initialScope(mode));
  const [routeClassId, setRouteClassId] = useState("");
  const [queryStudentId, setQueryStudentId] = useState("");
  const [classId, setClassId] = useState("");
  const [academicYearId, setAcademicYearId] = useState("");
  const [students, setStudents] = useState<Enrollment[]>([]);
  const [studentsLoading, setStudentsLoading] = useState(false);
  const [categoryId, setCategoryId] = useState("");
  const [recordTypeId, setRecordTypeId] = useState("");
  const [studentIds, setStudentIds] = useState<string[]>([]);
  const [observations, setObservations] = useState("");
  const [recordedAt, setRecordedAt] = useState(new Date().toISOString().slice(0, 16));
  const [message, setMessage] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);
  const [editId, setEditId] = useState("");
  const selectedCategory = categories.find((item) => item.id === categoryId);
  const activeTypes = selectedCategory?.types ?? [];
  const applyToClass = scopeMode === "class";
  const isMultiple = scopeMode === "multiple";
  const allStudentsSelected = students.length > 0 && studentIds.length === students.length;

  useEffect(() => {
    fetch("/api/catalog").then((response) => response.json()).then((payload) => setCategories(payload.categories ?? [])).catch(() => undefined);
  }, []);

  useEffect(() => {
    const query = new URLSearchParams(window.location.search);
    setRouteClassId(query.get("classId") ?? "");
    setQueryStudentId(query.get("student") ?? "");
    setEditId(query.get("edit") ?? "");
  }, []);

  useEffect(() => {
    if (!editId) return;
    fetch(`/api/records/${editId}`).then((response) => response.ok ? response.json() : Promise.reject()).then(async (record) => {
      setScopeMode("individual");
      setAcademicYearId(record.academicYearId);
      setClassId(record.classId);
      setStudentIds([record.studentId]);
      setCategoryId(record.categoryId);
      setRecordTypeId(record.recordTypeId ?? "");
      setObservations(record.observations ?? "");
      setRecordedAt(new Date(record.recordedAt).toISOString().slice(0, 16));
      const studentsResponse = await fetch(`/api/students?classId=${encodeURIComponent(record.classId)}`);
      if (!studentsResponse.ok) throw new Error("students");
      setStudents(await studentsResponse.json());
    }).catch(() => setMessage("Não foi possível carregar o registro."));
  }, [editId]);

  useEffect(() => {
    if (editId) return;
    let cancelled = false;
    async function loadContextClass() {
      setStudents([]);
      setStudentIds([]);
      setStudentsLoading(true);
      let nextClassId = context.classId !== "all" ? context.classId : "";
      let nextAcademicYearId = context.academicYearId;
      try {
        if (routeClassId) {
          const classResponse = await fetch(`/api/classes/${routeClassId}`);
          if (!classResponse.ok) throw new Error("class");
          const schoolClass = await classResponse.json();
          nextClassId = schoolClass.id;
          nextAcademicYearId = schoolClass.academicYearId;
        }
        if (cancelled) return;
        setClassId(nextClassId);
        setAcademicYearId(nextAcademicYearId);
        if (!nextClassId) return;
        const studentsResponse = await fetch(`/api/students?classId=${encodeURIComponent(nextClassId)}`);
        if (!studentsResponse.ok) throw new Error("students");
        const nextStudents = await studentsResponse.json() as Enrollment[];
        if (cancelled) return;
        setStudents(nextStudents);
        if (queryStudentId && initialScope(mode) === "individual" && nextStudents.some((item) => item.student.id === queryStudentId)) setStudentIds([queryStudentId]);
      } catch {
        if (!cancelled) setMessage("Não foi possível carregar a turma selecionada.");
      } finally {
        if (!cancelled) setStudentsLoading(false);
      }
    }
    loadContextClass();
    return () => { cancelled = true; };
  }, [context.academicYearId, context.classId, editId, mode, queryStudentId, routeClassId]);

  function selectScope(nextScope: ScopeMode) {
    setScopeMode(nextScope);
    setMessage("");
    if (nextScope === "class") setStudentIds([]);
    if (nextScope === "individual") setStudentIds((current) => current.slice(0, 1));
  }

  function selectAllStudents() {
    if (!students.length) {
      setMessage("Selecione uma turma com alunos para usar esta ação.");
      return;
    }
    setScopeMode("multiple");
    setStudentIds(allStudentsSelected ? [] : students.map((item) => item.student.id));
    setMessage("");
  }

  function selectWholeClass() {
    if (!classId) {
      setMessage("Selecione uma turma no cabeçalho antes de aplicar o registro à turma inteira.");
      return;
    }
    setScopeMode("class");
    setStudentIds([]);
    setMessage("");
  }

  function selectCategory(value: string) {
    setCategoryId(value);
    setRecordTypeId("");
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    setMessage("");
    setSuccess("");
    if (!academicYearId || !classId) {
      setMessage("Selecione um ano letivo e uma turma no cabeçalho.");
      return;
    }
    if (!categoryId || !recordTypeId) {
      setMessage("Selecione primeiro uma categoria e depois um tipo de registro.");
      return;
    }
    if (!applyToClass && !studentIds.length) {
      setMessage("Selecione pelo menos um aluno.");
      return;
    }
    if (selectedCategory?.name === "Outros" && !observations.trim()) {
      setMessage("A descrição é obrigatória para a categoria Outros.");
      return;
    }
    setLoading(true);
    const response = await fetch(editId ? `/api/records/${editId}` : "/api/records", {
      method: editId ? "PATCH" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ academicYearId, classId, studentIds, categoryId, recordTypeId, observations, recordedAt, applyToClass, entryMode: mode === "quick" ? "QUICK" : "NORMAL" }),
    });
    const body = await response.json();
    setLoading(false);
    if (!response.ok) {
      setMessage(body.error ?? "Não foi possível salvar o registro.");
      return;
    }
    setSuccess(editId ? "Registro atualizado." : `Registro salvo para ${body.count} aluno(s).`);
    if (!editId) setStudentIds([]);
    setObservations("");
  }

  const scopes: Array<{ id: ScopeMode; label: string; icon: typeof UserRound }> = [
    { id: "individual", label: "Um aluno", icon: UserRound },
    { id: "multiple", label: "Vários alunos", icon: Users },
    { id: "class", label: "Turma inteira", icon: School },
  ];

  return <form className="form-card" onSubmit={submit}>
    <div className="context-notice"><span className="context-notice-dot" /><span>Contexto ativo: <strong>{academicYearId ? "ano selecionado" : "selecione um ano"}</strong> · <strong>{classId ? "turma selecionada" : "selecione uma turma"}</strong></span></div>
    <div className="form-divider" />
    <div className="form-grid">
      <div className="field form-grid-wide">
        <span>Aplicar registro para</span>
        <div className="record-scope-options" role="tablist" aria-label="Escopo do registro">
          {scopes.map(({ id, label, icon: Icon }) => <button className={`record-scope-option ${scopeMode === id ? "is-active" : ""}`} key={id} type="button" role="tab" aria-selected={scopeMode === id} onClick={() => selectScope(id)}><Icon size={15} />{label}</button>)}
        </div>
      </div>
      {!applyToClass ? <div className="field form-grid-wide">
        <span>{isMultiple ? "Selecione os alunos" : "Aluno"}</span>
        <div className="selection-toolbar">
          <span className="form-hint" style={{ marginTop: 0 }}>{studentsLoading ? "Carregando alunos..." : `${students.length} aluno(s) disponível(is)`}</span>
          <div className="selection-toolbar-actions">
            {isMultiple ? <button className="button button-light" type="button" onClick={selectAllStudents}>{allStudentsSelected ? "Limpar seleção" : "Selecionar todos"}</button> : null}
            <button className="button button-secondary" type="button" onClick={selectWholeClass}><School size={14} />Selecionar turma inteira</button>
          </div>
        </div>
        <div className="selection-list">
          {students.map((item) => <label className={`selection-item ${studentIds.includes(item.student.id) ? "is-selected" : ""}`} key={item.id}>
            <input aria-label={`Selecionar ${item.student.fullName}`} type={isMultiple ? "checkbox" : "radio"} name="student" checked={studentIds.includes(item.student.id)} onChange={() => setStudentIds(isMultiple ? (studentIds.includes(item.student.id) ? studentIds.filter((id) => id !== item.student.id) : [...studentIds, item.student.id]) : [item.student.id])} />
            <span className="selection-student-number">{item.callNumber ?? "—"}</span>
            <span className="selection-student-name">{item.student.fullName}</span>
          </label>)}
          {!students.length ? <p className="form-hint">Selecione uma turma no topo para carregar os alunos.</p> : null}
        </div>
      </div> : <div className="field form-grid-wide">
        <span>Aplicar à turma inteira</span>
        <div className="success-line"><CheckCircle2 size={16} />Todos os {students.length} alunos ativos da turma serão incluídos no mesmo registro.</div>
      </div>}
      <label className="field"><span>Categoria</span><select required value={categoryId} onChange={(event) => selectCategory(event.target.value)}><option value="">Selecione primeiro uma categoria</option>{categories.map((category) => <option key={category.id} value={category.id}>{category.name}</option>)}</select></label>
      <label className="field"><span>Tipo do registro</span><select required disabled={!categoryId} value={recordTypeId} onChange={(event) => setRecordTypeId(event.target.value)}><option value="">{categoryId ? "Selecione o tipo" : "Selecione primeiro uma categoria."}</option>{activeTypes.map((type) => <option key={type.id} value={type.id}>{type.name}</option>)}</select></label>
      <label className="field"><span>Data</span><div className="input-with-icon"><CalendarDays size={16} /><input type="datetime-local" value={recordedAt} onChange={(event) => setRecordedAt(event.target.value)} /></div></label>
      <label className="field"><span>Horário</span><div className="input-with-icon"><Clock3 size={16} /><input type="time" defaultValue={new Date().toTimeString().slice(0, 5)} /></div></label>
      <label className="field form-grid-wide"><span>Descrição ou observação {selectedCategory?.name === "Outros" ? "(obrigatória)" : "(opcional)"}</span><textarea required={selectedCategory?.name === "Outros"} value={observations} onChange={(event) => setObservations(event.target.value)} placeholder={selectedCategory?.name === "Outros" ? "Explique a situação registrada..." : "Adicione contexto ao registro..."} /></label>
    </div>
    {isMultiple && studentIds.length ? <div className="info-box"><FileText size={17} /><div><strong>{studentIds.length} aluno(s) selecionado(s)</strong><p>{students.filter((item) => studentIds.includes(item.student.id)).map((item) => item.student.fullName).join(", ")}</p></div></div> : null}
    {success ? <div className="success-line" style={{ marginTop: 17 }}><CheckCircle2 size={16} />{success} <Link href={studentIds[0] ? `/students/${studentIds[0]}/history` : classId ? `/classes/${classId}` : "/students"} className="text-link">Ver histórico</Link></div> : null}
    {message ? <div className="form-error" style={{ marginTop: 17 }}>{message}</div> : null}
    <div className="form-actions"><Link href="/dashboard" className="button button-light">Cancelar</Link><button className="button button-primary" type="submit" disabled={loading}>{loading ? "Salvando..." : <><Sparkles size={16} />Salvar registro</>}</button></div>
  </form>;
}

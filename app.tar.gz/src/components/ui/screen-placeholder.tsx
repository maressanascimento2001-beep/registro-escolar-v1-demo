import type { LucideIcon } from "lucide-react";
import { ArrowRight, Construction } from "lucide-react";
import Link from "next/link";

type Action = { label: string; href: string; variant?: "primary" | "secondary" };

export function ScreenPlaceholder({ title, description, icon: Icon = Construction, actions = [], children, eyebrow = "Em preparação" }: Readonly<{ title: string; description: string; icon?: LucideIcon; actions?: Action[]; children?: React.ReactNode; eyebrow?: string }>) {
  return <div className="placeholder-page"><div className="placeholder-hero"><div className="placeholder-icon"><Icon size={27} /></div><div><p className="eyebrow">{eyebrow}</p><h1>{title}</h1><p className="page-description">{description}</p></div></div>{children ?? <div className="empty-state"><div className="empty-state-symbol"><Icon size={25} /></div><h2>Estrutura pronta para a próxima sprint</h2><p>Esta tela já faz parte da navegação do Registro Escolar e receberá suas regras de negócio nas próximas etapas.</p>{actions.length ? <div className="empty-actions">{actions.map((action) => <Link key={action.href} href={action.href as never} className={`button button-${action.variant ?? "secondary"}`}>{action.label}<ArrowRight size={16} /></Link>)}</div> : null}</div>}</div>;
}

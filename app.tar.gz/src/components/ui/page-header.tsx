import type { LucideIcon } from "lucide-react";
import { ArrowLeft } from "lucide-react";
import Link from "next/link";

type PageHeaderProps = {
  eyebrow?: string;
  title: string;
  description?: string;
  icon?: LucideIcon;
  backHref?: string;
  actions?: React.ReactNode;
};

export function PageHeader({ eyebrow, title, description, icon: Icon, backHref, actions }: PageHeaderProps) {
  return <div className="page-header"><div className="page-heading">{backHref ? <Link href={backHref as never} className="back-link"><ArrowLeft size={16} /> Voltar</Link> : null}<div className="heading-title-row">{Icon ? <span className="heading-icon"><Icon size={22} /></span> : null}<div><p className="eyebrow">{eyebrow ?? "Registro Escolar"}</p><h1>{title}</h1>{description ? <p className="page-description">{description}</p> : null}</div></div></div>{actions ? <div className="page-actions">{actions}</div> : null}</div>;
}

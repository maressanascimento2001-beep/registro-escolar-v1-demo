import { Check, ChevronDown, Search, SlidersHorizontal } from "lucide-react";

export function ContextNotice() {
  return <div className="context-notice"><span className="context-notice-dot" /><span>Contexto ativo: <strong>2026</strong> · Todas as turmas</span></div>;
}

export function FilterBar({ searchPlaceholder = "Pesquisar...", children }: Readonly<{ searchPlaceholder?: string; children?: React.ReactNode }>) {
  return <div className="filter-bar"><div className="search-field"><Search size={17} /><input placeholder={searchPlaceholder} /></div>{children}<button className="button button-light"><SlidersHorizontal size={16} />Filtros</button></div>;
}

export function SelectField({ label, value = "Selecionar" }: Readonly<{ label: string; value?: string }>) {
  return <label className="field"><span>{label}</span><select defaultValue="value"><option value="value">{value}</option></select><ChevronDown className="select-chevron" size={16} /></label>;
}

export function SuccessLine({ children }: Readonly<{ children: React.ReactNode }>) {
  return <div className="success-line"><Check size={16} />{children}</div>;
}

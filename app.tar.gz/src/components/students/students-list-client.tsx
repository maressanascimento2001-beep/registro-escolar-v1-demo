"use client";

import Link from "next/link";
import { Edit3, Eye, Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import { useWorkContext } from "@/components/context/use-context";

type Enrollment = { id: string; callNumber: number | null; student: { id: string; fullName: string }; class: { name: string; academicYear: { name: string } } };

export function StudentsListClient() {
  const context = useWorkContext();
  const [items, setItems] = useState<Enrollment[]>([]);
  const [q, setQ] = useState("");
  const [error, setError] = useState("");

  const load = () => {
    const params = new URLSearchParams();
    if (context.classId !== "all") params.set("classId", context.classId);
    if (q) params.set("q", q);
    fetch(`/api/students?${params}`).then((response) => response.json()).then((data) => { setError(""); setItems(data); }).catch(() => setError("Não foi possível carregar os alunos."));
  };

  useEffect(() => { load(); }, [context.classId]);

  async function remove(item: Enrollment) {
    if (!confirm(`Excluir o aluno ${item.student.fullName}? O histórico será preservado.`)) return;
    const response = await fetch(`/api/students/${item.student.id}`, { method: "DELETE" });
    if (response.ok) load();
    else {
      const body = await response.json().catch(() => null);
      setError(body?.error ?? "Não foi possível excluir o aluno.");
    }
  }

  return <><div className="filter-bar"><div className="search-field"><input value={q} onChange={(event) => setQ(event.target.value)} placeholder="Pesquisar por nome..." onKeyDown={(event) => { if (event.key === "Enter") load(); }} /></div><button className="button button-light" type="button" onClick={load}>Pesquisar</button></div>{error ? <div className="warning-box" style={{ marginBottom: 16 }}>{error}</div> : null}<div className="data-card"><table className="data-table"><thead><tr><th>Nº chamada</th><th>Aluno</th><th>Turma</th><th>Ano letivo</th><th /></tr></thead><tbody>{items.map((item) => <tr key={item.id}><td>{item.callNumber ?? "—"}</td><td><strong>{item.student.fullName}</strong></td><td><span className="badge badge-lilac">{item.class.name}</span></td><td>{item.class.academicYear.name}</td><td><div className="table-actions"><Link className="table-action" href={`/students/${item.student.id}`} aria-label={`Abrir ficha de ${item.student.fullName}`}><Eye size={15} /></Link><Link className="table-action" href={`/students/${item.student.id}/edit`} aria-label={`Editar aluno ${item.student.fullName}`}><Edit3 size={15} /></Link><button className="table-action" type="button" title="Excluir aluno" aria-label={`Excluir aluno ${item.student.fullName}`} onClick={() => remove(item)}><Trash2 size={15} /></button></div></td></tr>)}{!items.length ? <tr><td colSpan={5}><div className="table-empty">Nenhum aluno encontrado no contexto atual.</div></td></tr> : null}</tbody></table></div></>;
}

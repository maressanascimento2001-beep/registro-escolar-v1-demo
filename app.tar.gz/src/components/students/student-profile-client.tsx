"use client";

import Link from "next/link";
import { formatBrazilDate, isSameBrazilMonth } from "@/lib/timezone";
import { ArrowRight, ClipboardPenLine, Edit3, Plus, Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

type Student = { id: string; fullName: string; active: boolean; enrollments: Array<{ callNumber: number | null; class: { name: string; academicYear: { name: string }; discipline: { name: string } | null } }>; records: Array<{ id: string; recordedAt: string; category: { name: string }; recordType: { name: string } | null; observations: string | null; class: { name: string } }> };

export function StudentProfileClient({ studentId }: { studentId: string }) {
  const router = useRouter();
  const [student, setStudent] = useState<Student | null>(null);
  const [error, setError] = useState("");

  useEffect(() => { fetch(`/api/students/${studentId}`).then((response) => response.json()).then(setStudent).catch(() => setError("Não foi possível carregar o aluno.")); }, [studentId]);

  async function remove() {
    if (!student || !confirm(`Excluir o aluno ${student.fullName}? O histórico será preservado.`)) return;
    const response = await fetch(`/api/students/${student.id}`, { method: "DELETE" });
    if (response.ok) {
      router.push("/students");
      router.refresh();
    } else {
      const body = await response.json().catch(() => null);
      setError(body?.error ?? "Não foi possível excluir o aluno.");
    }
  }

  if (error && !student) return <div className="warning-box">{error}</div>;
  if (!student) return <div className="empty-state"><div className="empty-state-symbol"><ClipboardPenLine size={24} /></div><h2>Carregando ficha...</h2></div>;
  const enrollment = student.enrollments[0];
  return <><section className="profile-header"><div className="profile-main"><div className="profile-avatar">{student.fullName.split(" ").map((part) => part[0]).slice(0, 2).join("")}</div><div><h2>{student.fullName}</h2><p>Nº {enrollment?.callNumber ?? "—"} · {enrollment?.class.name ?? "Sem turma"} · {enrollment?.class.academicYear.name ?? "—"} · {enrollment?.class.discipline?.name ?? "Sem disciplina"}</p></div></div><span className={`badge ${student.active ? "badge-green" : "badge-beige"}`}>{student.active ? "Aluno ativo" : "Aluno inativo"}</span></section><div className="stats-inline"><div className="inline-stat"><strong>{student.records.length}</strong><span>Registros carregados</span></div><div className="inline-stat"><strong>{student.enrollments.length}</strong><span>Turmas vinculadas</span></div><div className="inline-stat"><strong>{student.records.filter((record) => isSameBrazilMonth(record.recordedAt)).length}</strong><span>Registros este mês</span></div></div><div className="tab-row"><Link className="tab is-active" href={`/students/${student.id}`}>Resumo</Link><Link className="tab" href={`/students/${student.id}/history`}>Histórico completo</Link></div><section className="data-card"><div className="section-card-heading" style={{ padding: 22, marginBottom: 0 }}><div><h2>Registros recentes</h2><p>Os mais recentes ficam primeiro.</p></div><Link href={`/students/${student.id}/history`} className="text-link">Ver histórico <ArrowRight size={13} style={{ verticalAlign: "-2px" }} /></Link></div><div className="record-list" style={{ padding: "0 22px 12px" }}>{student.records.slice(0, 5).map((record) => <div className="record-row" key={record.id}><div className="record-avatar"><ClipboardPenLine size={15} /></div><div className="record-main"><strong>{record.recordType?.name ?? "Registro personalizado"}</strong><span>{record.category.name} · {record.class.name} · {record.observations ?? "Sem observação"}</span></div><span className="record-meta">{formatBrazilDate(record.recordedAt)}</span></div>)}</div></section>{error ? <div className="form-error" style={{ marginTop: 16 }}>{error}</div> : null}<div className="empty-actions" style={{ justifyContent: "flex-end", marginTop: 16 }}><button type="button" className="button button-danger" onClick={remove}><Trash2 size={15} />Excluir aluno</button><Link href={`/students/${student.id}/edit`} className="button button-light"><Edit3 size={14} />Editar aluno</Link><Link href={`/records/individual?student=${student.id}`} className="button button-primary"><Plus size={15} />Novo Registro</Link></div></>;
}

import Link from "next/link";
import { Check, FileText, UploadCloud } from "lucide-react";

export function ImportStepper({ active }: Readonly<{ active: number }>) { const labels = ["Enviar PDF", "Visualizar alunos", "Escolher modo", "Confirmar"]; return <div className="stepper">{labels.map((label, index) => <div key={label} className="step-wrap" style={{ display: "flex", alignItems: "center" }}><div className={`step ${active === index + 1 ? "is-active" : ""} ${active > index + 1 ? "is-done" : ""}`}><span className="step-number">{active > index + 1 ? <Check size={14} /> : index + 1}</span><span>{label}</span></div>{index < labels.length - 1 ? <span className={`step-line ${active > index + 1 ? "is-done" : ""}`} /> : null}</div>)}</div>; }

export function UploadDropzone() { return <div className="upload-dropzone"><div className="upload-symbol"><UploadCloud size={27} /></div><h2>Arraste o PDF aqui</h2><p>ou escolha um arquivo do seu computador</p><button className="button button-secondary" type="button">Selecionar PDF</button><small>Somente PDF textual · até 10 MB</small></div>; }

export function ImportNavigation({ nextHref, nextLabel = "Continuar", backHref = "/classes/5-a" }: Readonly<{ nextHref: string; nextLabel?: string; backHref?: string }>) { return <div className="form-actions"><Link href={backHref as never} className="button button-light">Cancelar</Link><Link href={nextHref as never} className="button button-primary">{nextLabel} <span aria-hidden="true">→</span></Link></div>; }

export function FoundStudentList() { return <div className="data-card"><table className="data-table"><thead><tr><th>Nº encontrado</th><th>Nome do aluno</th><th>Status</th></tr></thead><tbody>{["Ana Souza", "Beatriz Lima", "Carlos Mendes", "Daniela Rocha", "Eduardo Alves"].map((student, index) => <tr key={student}><td>{String(index + 1).padStart(2, "0")}</td><td><strong>{student}</strong></td><td><span className="badge badge-green">Novo aluno</span></td></tr>)}</tbody></table></div>; }

export function ImportFileCard() { return <div className="import-file-card"><div className="file-icon"><FileText size={20} /></div><div><strong>alunos_5a_2026.pdf</strong><small>PDF textual · 128 KB</small></div><span className="badge badge-green">Pronto</span></div>; }

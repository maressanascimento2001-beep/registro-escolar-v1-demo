"use client";

import { useEffect, useMemo, useState } from "react";

type ContextData = { academicYears: Array<{ id: string; name: string; classes: Array<{ id: string; name: string; disciplineId: string | null; discipline?: { name: string } | null }> }>; disciplines: Array<{ id: string; name: string }> };
const storageKey = "registro-escolar-contexto";

export function ContextControls() {
  const [data, setData] = useState<ContextData>({ academicYears: [], disciplines: [] });
  const [yearId, setYearId] = useState(""); const [classId, setClassId] = useState("all"); const [disciplineId, setDisciplineId] = useState("all");
  const year = data.academicYears.find((item) => item.id === yearId); const classes = year?.classes ?? [];
  const visibleClasses = useMemo(() => classes, [classes]);

  useEffect(() => { fetch("/api/context").then((response) => response.ok ? response.json() : null).then((payload: ContextData | null) => { if (!payload) return; setData(payload); const saved = window.localStorage.getItem(storageKey); const context = saved ? JSON.parse(saved) : null; const nextYear = payload.academicYears.find((item) => item.id === context?.academicYearId)?.id ?? payload.academicYears[0]?.id ?? ""; const nextClass = payload.academicYears.find((item) => item.id === nextYear)?.classes.some((item) => item.id === context?.classId) ? context.classId : "all"; const nextDiscipline = payload.disciplines.some((item) => item.id === context?.disciplineId) ? context.disciplineId : "all"; setYearId(nextYear); setClassId(nextClass ?? "all"); setDisciplineId(nextDiscipline ?? "all"); }).catch(() => undefined); }, []);
  function save(next: { academicYearId: string; classId: string; disciplineId: string }) { window.localStorage.setItem(storageKey, JSON.stringify(next)); window.dispatchEvent(new CustomEvent("registro-contexto", { detail: next })); }
  function onYearChange(value: string) { setYearId(value); setClassId("all"); setDisciplineId("all"); save({ academicYearId: value, classId: "all", disciplineId: "all" }); }
  function onClassChange(value: string) { const item = classes.find((entry) => entry.id === value); const nextDiscipline = item?.disciplineId ?? disciplineId; setClassId(value); if (item?.disciplineId) setDisciplineId(item.disciplineId); save({ academicYearId: yearId, classId: value, disciplineId: nextDiscipline }); }
  function onDisciplineChange(value: string) { setDisciplineId(value); setClassId("all"); save({ academicYearId: yearId, classId: "all", disciplineId: value }); }

  return <div className="context-selectors"><label>Ano letivo<select value={yearId} onChange={(event) => onYearChange(event.target.value)}><option value="">Selecionar</option>{data.academicYears.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label><label>Disciplina<select value={disciplineId} onChange={(event) => onDisciplineChange(event.target.value)}><option value="all">Todas</option>{data.disciplines.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label><label>Turma<select value={classId} onChange={(event) => onClassChange(event.target.value)}><option value="all">Todas</option>{visibleClasses.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label></div>;
}

"use client";

import { useEffect, useState } from "react";

type ContextData = { academicYears: Array<{ id: string; name: string; classes: Array<{ id: string; name: string; disciplineId: string | null; discipline?: { name: string } | null }> }>; disciplines: Array<{ id: string; name: string }> };
const storageKey = "registro-escolar-contexto";

type Props = { compact?: boolean };

function readSavedContext() {
  try {
    const saved = window.localStorage.getItem(storageKey);
    return saved ? JSON.parse(saved) as { academicYearId?: string; classId?: string; disciplineId?: string } : null;
  } catch {
    return null;
  }
}

export function ContextControls({ compact = false }: Props) {
  const [data, setData] = useState<ContextData>({ academicYears: [], disciplines: [] });
  const [loaded, setLoaded] = useState(false);
  const [yearId, setYearId] = useState(""); const [classId, setClassId] = useState("all"); const [disciplineId, setDisciplineId] = useState("all");
  const year = data.academicYears.find((item) => item.id === yearId); const classes = year?.classes ?? [];

  useEffect(() => {
    let cancelled = false;
    fetch("/api/context").then((response) => response.ok ? response.json() : null).then((payload: ContextData | null) => {
      if (!payload || cancelled) return;
      const saved = readSavedContext();
      const nextYear = payload.academicYears.find((item) => item.id === saved?.academicYearId)?.id ?? payload.academicYears[0]?.id ?? "";
      const nextYearClasses = payload.academicYears.find((item) => item.id === nextYear)?.classes ?? [];
      const nextClass = nextYearClasses.some((item) => item.id === saved?.classId) ? saved?.classId : "all";
      const nextDiscipline = saved?.disciplineId === "all" || payload.disciplines.some((item) => item.id === saved?.disciplineId) ? saved?.disciplineId ?? "all" : "all";
      setData(payload);
      setYearId(nextYear);
      setClassId(nextClass ?? "all");
      setDisciplineId(nextDiscipline);
      setLoaded(true);
    }).catch(() => setLoaded(true));
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    const sync = (event: Event) => {
      const next = (event as CustomEvent<{ academicYearId?: string; classId?: string; disciplineId?: string }>).detail;
      if (!next) return;
      setYearId(next.academicYearId ?? "");
      setClassId(next.classId ?? "all");
      setDisciplineId(next.disciplineId ?? "all");
    };
    window.addEventListener("registro-contexto", sync);
    return () => window.removeEventListener("registro-contexto", sync);
  }, []);

  function save(next: { academicYearId: string; classId: string; disciplineId: string }) { window.localStorage.setItem(storageKey, JSON.stringify(next)); window.dispatchEvent(new CustomEvent("registro-contexto", { detail: next })); }
  function onYearChange(value: string) { setYearId(value); setClassId("all"); setDisciplineId("all"); save({ academicYearId: value, classId: "all", disciplineId: "all" }); }
  function onClassChange(value: string) { const item = classes.find((entry) => entry.id === value); const nextClass = item?.id ?? "all"; const nextDiscipline = item?.disciplineId ?? disciplineId; setClassId(nextClass); if (item?.disciplineId) setDisciplineId(item.disciplineId); save({ academicYearId: yearId, classId: nextClass, disciplineId: nextDiscipline }); }
  function onDisciplineChange(value: string) { setDisciplineId(value); setClassId("all"); save({ academicYearId: yearId, classId: "all", disciplineId: value }); }

  return <div className={`context-selectors ${compact ? "context-selectors-compact" : ""}`}><label>Ano letivo<select disabled={!loaded} value={yearId} onChange={(event) => onYearChange(event.target.value)}><option value="">Selecionar</option>{data.academicYears.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label><label>Disciplina<select disabled={!loaded || !yearId} value={disciplineId} onChange={(event) => onDisciplineChange(event.target.value)}><option value="all">Todas</option>{data.disciplines.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label><label>Turma<select disabled={!loaded || !yearId} value={classId} onChange={(event) => onClassChange(event.target.value)}><option value="all">Todas</option>{classes.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label></div>;
}

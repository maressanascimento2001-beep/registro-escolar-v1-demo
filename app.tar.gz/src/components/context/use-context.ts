"use client";

import { useEffect, useState } from "react";

export type WorkContext = { academicYearId: string; classId: string; disciplineId: string };
const key = "registro-escolar-contexto";

export function useWorkContext() {
  const [context, setContext] = useState<WorkContext>({ academicYearId: "", classId: "all", disciplineId: "all" });
  useEffect(() => { const read = () => { const saved = window.localStorage.getItem(key); if (saved) setContext(JSON.parse(saved)); }; read(); window.addEventListener("registro-contexto", read); return () => window.removeEventListener("registro-contexto", read); }, []);
  return context;
}

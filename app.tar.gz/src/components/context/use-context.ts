"use client";

import { useEffect, useState } from "react";

export type WorkContext = { academicYearId: string; classId: string; disciplineId: string };
const key = "registro-escolar-contexto";

export function useWorkContext() {
  const [context, setContext] = useState<WorkContext>({ academicYearId: "", classId: "all", disciplineId: "all" });
  useEffect(() => {
    const read = (event?: Event) => {
      try {
        const detail = event ? (event as CustomEvent<Partial<WorkContext>>).detail : null;
        const saved = window.localStorage.getItem(key);
        const next = detail ?? (saved ? JSON.parse(saved) as Partial<WorkContext> : null);
        if (next) setContext({ academicYearId: next.academicYearId ?? "", classId: next.classId ?? "all", disciplineId: next.disciplineId ?? "all" });
      } catch {
        setContext({ academicYearId: "", classId: "all", disciplineId: "all" });
      }
    };
    read();
    window.addEventListener("registro-contexto", read);
    window.addEventListener("storage", read);
    return () => { window.removeEventListener("registro-contexto", read); window.removeEventListener("storage", read); };
  }, []);
  return context;
}

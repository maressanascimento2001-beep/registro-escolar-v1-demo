import type { ReportRecord, ReportStudent } from "@/lib/pdf-report";
import { formatBrazilDate } from "@/lib/timezone";

function escapeHtml(value: string | number | null | undefined) {
  return String(value ?? "-")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function formatDate(value: Date | string) {
  return formatBrazilDate(value);
}

function recordRows(records: ReportRecord[]) {
  if (!records.length) return '<tr><td colspan="4" class="empty">Nenhum registro no período selecionado.</td></tr>';
  return records.map((record) => `<tr>
    <td>${escapeHtml(formatDate(record.recordedAt))}</td>
    <td>${escapeHtml(record.category.name)}</td>
    <td>${escapeHtml(record.recordType?.name ?? "Registro personalizado")}</td>
    <td>${escapeHtml(record.observations ?? "-")}</td>
  </tr>`).join("");
}

function studentSection(student: ReportStudent, period: string, issuedAt: Date) {
  return `<section class="student-report">
    <header>
      <div>
        <div class="eyebrow">RELATÓRIO DE REGISTROS</div>
        <h1>Registro Escolar</h1>
      </div>
      <div class="issued">Emitido em<br><strong>${escapeHtml(formatDate(issuedAt))}</strong></div>
    </header>
    <div class="rule"></div>
    <div class="title">Relatório de registros</div>
    <table class="identity">
      <tr><td><span>Nome do aluno</span><strong>${escapeHtml(student.fullName)}</strong></td><td><span>Turma</span><strong>${escapeHtml(student.className)}</strong></td></tr>
      <tr><td><span>Ano letivo</span><strong>${escapeHtml(student.academicYear)}</strong></td><td><span>Disciplina</span><strong>${escapeHtml(student.discipline || "Não informada")}</strong></td></tr>
      <tr><td colspan="2"><span>Período do filtro</span><strong>${escapeHtml(period)}</strong></td></tr>
    </table>
    <table class="records">
      <thead><tr><th>Data</th><th>Categoria</th><th>Tipo do registro</th><th>Observações</th></tr></thead>
      <tbody>${recordRows(student.records)}</tbody>
    </table>
  </section>`;
}

export function createDocReport(students: ReportStudent[], period: string, issuedAt = new Date()) {
  const sections = students.length ? students.map((student) => studentSection(student, period, issuedAt)).join("") : '<section class="student-report"><p>Nenhum aluno encontrado para os filtros selecionados.</p></section>';
  const html = `<!DOCTYPE html>
<html lang="pt-BR"><head><meta charset="utf-8"><title>Relatório de registros</title>
<style>
  @page { size: A4; margin: 1.7cm; }
  body { margin: 0; color: #30302e; background: #fff; font-family: Arial, Helvetica, sans-serif; font-size: 10pt; }
  .student-report { page-break-after: always; }
  .student-report:last-child { page-break-after: auto; }
  header { display: flex; justify-content: space-between; align-items: flex-start; }
  .eyebrow { color: #686864; font-size: 8pt; font-weight: bold; letter-spacing: 1.6pt; }
  h1 { margin: 6pt 0 0; color: #30302e; font-size: 20pt; font-weight: normal; }
  .issued { color: #777773; font-size: 8pt; text-align: right; line-height: 1.5; }
  .issued strong { color: #30302e; }
  .rule { height: 1pt; margin: 16pt 0; background: #5c5c58; }
  .title { margin-bottom: 14pt; color: #454541; font-size: 13pt; font-weight: bold; }
  .identity { width: 100%; margin-bottom: 18pt; border-collapse: collapse; }
  .identity td { width: 50%; padding: 7pt 8pt 7pt 0; vertical-align: top; }
  .identity span { display: block; color: #858580; font-size: 8pt; }
  .identity strong { display: block; margin-top: 3pt; color: #30302e; font-size: 10pt; }
  .records { width: 100%; border-collapse: collapse; }
  .records th { padding: 7pt; color: #4e4e4a; background: #eeeeeb; border-bottom: 1pt solid #bdbdb8; font-size: 8pt; text-align: left; text-transform: uppercase; }
  .records td { padding: 8pt 7pt; border-bottom: .5pt solid #d5d5d0; color: #454541; font-size: 9pt; line-height: 1.4; vertical-align: top; }
  .records td:nth-child(1) { width: 16%; } .records td:nth-child(2) { width: 18%; } .records td:nth-child(3) { width: 26%; } .records td:nth-child(4) { width: 40%; }
  .empty { color: #777773; text-align: center; }
</style></head><body>${sections}</body></html>`;
  return new TextEncoder().encode(html);
}

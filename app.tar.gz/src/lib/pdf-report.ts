import { PageSizes, PDFDocument, StandardFonts, rgb } from "pdf-lib";

const colors = { rose: rgb(0.596, 0.427, 0.478), graphite: rgb(0.204, 0.188, 0.224), muted: rgb(0.46, 0.43, 0.47), line: rgb(0.90, 0.87, 0.89), soft: rgb(0.965, 0.91, 0.925) };

function wrap(text: string, font: Awaited<ReturnType<PDFDocument["embedFont"]>>, size: number, maxWidth: number) {
  const words = String(text || "—").split(/\s+/); const lines: string[] = []; let line = "";
  for (const word of words) { const next = line ? `${line} ${word}` : word; if (font.widthOfTextAtSize(next, size) > maxWidth && line) { lines.push(line); line = word; } else line = next; }
  if (line) lines.push(line); return lines.length ? lines : ["—"];
}

export type ReportRecord = { recordedAt: Date | string; category: { name: string }; recordType: { name: string } | null; observations: string | null };
export type ReportStudent = { fullName: string; callNumber?: number | null; className: string; academicYear: string; discipline: string; records: ReportRecord[] };

export async function createPdfReport(students: ReportStudent[], period: string) {
  const pdf = await PDFDocument.create();
  const regular = await pdf.embedFont(StandardFonts.Helvetica); const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const margin = 42; const pageWidth = PageSizes.A4[0]; const pageHeight = PageSizes.A4[1];
  for (const student of students) {
    let page = pdf.addPage(PageSizes.A4); let y = pageHeight - margin;
    const header = () => { page.drawText("REGISTRO ESCOLAR", { x: margin, y, size: 9, font: bold, color: colors.rose }); y -= 22; page.drawText("Relatório de registros", { x: margin, y, size: 20, font: bold, color: colors.graphite }); page.drawText(`Emitido em ${new Date().toLocaleDateString("pt-BR")}`, { x: pageWidth - margin - 130, y: y + 2, size: 8, font: regular, color: colors.muted }); y -= 30; page.drawLine({ start: { x: margin, y }, end: { x: pageWidth - margin, y }, thickness: 1.5, color: colors.rose }); y -= 22; };
    const identity = () => { page.drawText(student.fullName, { x: margin, y, size: 15, font: bold, color: colors.graphite }); y -= 18; page.drawText(`Nº chamada: ${student.callNumber ?? "—"}   ·   Turma: ${student.className}   ·   Ano letivo: ${student.academicYear}`, { x: margin, y, size: 8.5, font: regular, color: colors.muted }); y -= 14; page.drawText(`Disciplina: ${student.discipline || "—"}   ·   Período: ${period}`, { x: margin, y, size: 8.5, font: regular, color: colors.muted }); y -= 27; };
    const tableHeader = () => { page.drawRectangle({ x: margin, y: y - 15, width: pageWidth - margin * 2, height: 22, color: colors.soft }); page.drawText("DATA", { x: margin + 7, y: y - 8, size: 7, font: bold, color: colors.muted }); page.drawText("CATEGORIA", { x: margin + 90, y: y - 8, size: 7, font: bold, color: colors.muted }); page.drawText("TIPO DO REGISTRO", { x: margin + 175, y: y - 8, size: 7, font: bold, color: colors.muted }); page.drawText("OBSERVAÇÕES", { x: margin + 335, y: y - 8, size: 7, font: bold, color: colors.muted }); y -= 29; };
    header(); identity(); tableHeader();
    for (const record of student.records) {
      const date = new Date(record.recordedAt).toLocaleDateString("pt-BR"); const obsLines = wrap(record.observations ?? "—", regular, 7.5, 170); const rowHeight = Math.max(24, obsLines.length * 11 + 9);
      if (y - rowHeight < margin + 34) { page = pdf.addPage(PageSizes.A4); y = pageHeight - margin; header(); page.drawText(`${student.fullName} · continuação`, { x: margin, y, size: 11, font: bold, color: colors.graphite }); y -= 23; tableHeader(); }
      page.drawLine({ start: { x: margin, y: y - rowHeight }, end: { x: pageWidth - margin, y: y - rowHeight }, thickness: .5, color: colors.line });
      page.drawText(date, { x: margin + 7, y: y - 14, size: 7.5, font: regular, color: colors.graphite }); page.drawText(record.category.name, { x: margin + 90, y: y - 14, size: 7.5, font: regular, color: colors.graphite });
      for (const [index, line] of wrap(record.recordType?.name ?? "Outra situação", regular, 7.5, 145).entries()) page.drawText(line, { x: margin + 175, y: y - 14 - index * 11, size: 7.5, font: regular, color: colors.graphite });
      for (const [index, line] of obsLines.entries()) page.drawText(line, { x: margin + 335, y: y - 14 - index * 11, size: 7.5, font: regular, color: colors.graphite });
      y -= rowHeight;
    }
    page.drawLine({ start: { x: margin, y: margin + 22 }, end: { x: pageWidth - margin, y: margin + 22 }, thickness: .5, color: colors.line }); page.drawText("Registro Escolar · documento para acompanhamento pedagógico", { x: margin, y: margin + 9, size: 7, font: regular, color: colors.muted }); page.drawText("Assinatura: ____________________________________", { x: pageWidth - margin - 190, y: margin + 9, size: 7, font: regular, color: colors.muted });
  }
  return pdf.save();
}

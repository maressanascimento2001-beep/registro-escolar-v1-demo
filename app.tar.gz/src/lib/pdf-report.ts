import { PageSizes, PDFDocument, StandardFonts, rgb } from "pdf-lib";

const colors = {
  graphite: rgb(0.204, 0.188, 0.224),
  muted: rgb(0.46, 0.43, 0.47),
  line: rgb(0.90, 0.87, 0.89),
  soft: rgb(0.965, 0.91, 0.925),
};

function wrap(text: string, font: Awaited<ReturnType<PDFDocument["embedFont"]>>, size: number, maxWidth: number) {
  const words = String(text || "-").split(/\s+/);
  const lines: string[] = [];
  let line = "";
  for (const word of words) {
    const next = line ? `${line} ${word}` : word;
    if (font.widthOfTextAtSize(next, size) > maxWidth && line) {
      lines.push(line);
      line = word;
    } else {
      line = next;
    }
  }
  if (line) lines.push(line);
  return lines.length ? lines : ["-"];
}

function formatDate(value: Date | string) {
  return new Date(value).toLocaleDateString("pt-BR");
}

export function formatReportPeriod(from?: string | null, to?: string | null) {
  if (!from && !to) return "Todos os registros";
  const start = from ? formatDate(`${from}T00:00:00`) : "Início";
  const end = to ? formatDate(`${to}T00:00:00`) : "Até a emissão";
  return `${start} a ${end}`;
}

export type ReportRecord = {
  recordedAt: Date | string;
  category: { name: string };
  recordType: { name: string } | null;
  observations: string | null;
};

export type ReportStudent = {
  fullName: string;
  callNumber?: number | null;
  className: string;
  academicYear: string;
  discipline: string;
  records: ReportRecord[];
};

export async function createPdfReport(students: ReportStudent[], period: string, issuedAt = new Date()) {
  const pdf = await PDFDocument.create();
  const regular = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const margin = 42;
  const pageWidth = PageSizes.A4[0];
  const pageHeight = PageSizes.A4[1];

  for (const student of students) {
    let page = pdf.addPage(PageSizes.A4);
    let y = pageHeight - margin;

    const drawHeader = () => {
      page.drawText("Relatório de registros", { x: margin, y, size: 19, font: bold, color: colors.graphite });
      page.drawText(`Emitido em: ${formatDate(issuedAt)}`, { x: pageWidth - margin - 112, y: y + 1, size: 8, font: regular, color: colors.muted });
      y -= 28;
      page.drawLine({ start: { x: margin, y }, end: { x: pageWidth - margin, y }, thickness: 1.2, color: colors.graphite });
      y -= 20;
    };

    const drawIdentity = () => {
      page.drawText("Nome do aluno", { x: margin, y, size: 7.5, font: bold, color: colors.muted });
      y -= 13;
      page.drawText(student.fullName, { x: margin, y, size: 13, font: bold, color: colors.graphite });
      y -= 20;
      page.drawText(`Nº de chamada: ${student.callNumber ?? "Não informado"}`, { x: margin, y, size: 8.5, font: regular, color: colors.muted });
      page.drawText(`Turma: ${student.className}`, { x: margin + 155, y, size: 8.5, font: regular, color: colors.muted });
      page.drawText(`Ano letivo: ${student.academicYear}`, { x: margin + 275, y, size: 8.5, font: regular, color: colors.muted });
      y -= 14;
      page.drawText(`Disciplina: ${student.discipline || "Não informada"}`, { x: margin, y, size: 8.5, font: regular, color: colors.muted });
      page.drawText(`Período do filtro: ${period}`, { x: margin + 210, y, size: 8.5, font: regular, color: colors.muted });
      y -= 25;
    };

    const drawTableHeader = () => {
      page.drawRectangle({ x: margin, y: y - 15, width: pageWidth - margin * 2, height: 22, color: colors.soft });
      page.drawText("DATA", { x: margin + 7, y: y - 8, size: 7, font: bold, color: colors.muted });
      page.drawText("CATEGORIA", { x: margin + 90, y: y - 8, size: 7, font: bold, color: colors.muted });
      page.drawText("TIPO DO REGISTRO", { x: margin + 175, y: y - 8, size: 7, font: bold, color: colors.muted });
      page.drawText("OBSERVAÇÕES", { x: margin + 335, y: y - 8, size: 7, font: bold, color: colors.muted });
      y -= 29;
    };

    drawHeader();
    drawIdentity();
    drawTableHeader();

    if (!student.records.length) {
      page.drawText("Nenhum registro no período selecionado.", { x: margin + 7, y: y - 14, size: 8, font: regular, color: colors.muted });
      continue;
    }

    for (const record of student.records) {
      const date = formatDate(record.recordedAt);
      const typeLines = wrap(record.recordType?.name ?? "Registro personalizado", regular, 7.5, 145);
      const obsLines = wrap(record.observations ?? "-", regular, 7.5, 170);
      const rowHeight = Math.max(24, Math.max(typeLines.length, obsLines.length) * 11 + 9);

      if (y - rowHeight < margin + 18) {
        page = pdf.addPage(PageSizes.A4);
        y = pageHeight - margin;
        drawHeader();
        page.drawText(`${student.fullName} - continuação`, { x: margin, y, size: 11, font: bold, color: colors.graphite });
        y -= 23;
        drawTableHeader();
      }

      page.drawLine({ start: { x: margin, y: y - rowHeight }, end: { x: pageWidth - margin, y: y - rowHeight }, thickness: 0.5, color: colors.line });
      page.drawText(date, { x: margin + 7, y: y - 14, size: 7.5, font: regular, color: colors.graphite });
      page.drawText(record.category.name, { x: margin + 90, y: y - 14, size: 7.5, font: regular, color: colors.graphite });
      for (const [index, line] of typeLines.entries()) page.drawText(line, { x: margin + 175, y: y - 14 - index * 11, size: 7.5, font: regular, color: colors.graphite });
      for (const [index, line] of obsLines.entries()) page.drawText(line, { x: margin + 335, y: y - 14 - index * 11, size: 7.5, font: regular, color: colors.graphite });
      y -= rowHeight;
    }
  }

  return pdf.save();
}

import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";

import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function currentUser() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) return null;

  let user = await prisma.user.findUnique({ where: { email: session.user.email } });
  if (!user) {
    const institution = await prisma.institution.findFirst({ orderBy: { createdAt: "asc" } }) ?? await prisma.institution.create({ data: { name: "Escola Registro Escolar" } });
    user = await prisma.user.create({ data: { institutionId: institution.id, name: session.user.name ?? "Professor", email: session.user.email, role: "PROFESSOR" } });
  }
  return user;
}

export function errorResponse(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status });
}

export function parseDate(value: unknown) {
  if (typeof value !== "string" || !value) return new Date();
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

export async function contextClass(classId: string, academicYearId: string, institutionId: string) {
  return prisma.schoolClass.findFirst({ where: { id: classId, academicYearId, academicYear: { institutionId } } });
}

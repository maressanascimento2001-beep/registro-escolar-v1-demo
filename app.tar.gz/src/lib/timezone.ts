export const BRAZIL_TIME_ZONE = "America/Sao_Paulo";

type DateParts = {
  year: number;
  month: number;
  day: number;
  hour: number;
  minute: number;
  second: number;
};

const dateTimeFormatter = new Intl.DateTimeFormat("en-CA", {
  timeZone: BRAZIL_TIME_ZONE,
  calendar: "gregory",
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
  hour: "2-digit",
  minute: "2-digit",
  second: "2-digit",
  hourCycle: "h23",
});

const dateFormatter = new Intl.DateTimeFormat("pt-BR", {
  timeZone: BRAZIL_TIME_ZONE,
  calendar: "gregory",
  day: "2-digit",
  month: "2-digit",
  year: "numeric",
});

const dateTimeDisplayFormatter = new Intl.DateTimeFormat("pt-BR", {
  timeZone: BRAZIL_TIME_ZONE,
  calendar: "gregory",
  dateStyle: "short",
  timeStyle: "short",
});

const timeFormatter = new Intl.DateTimeFormat("pt-BR", {
  timeZone: BRAZIL_TIME_ZONE,
  hour: "2-digit",
  minute: "2-digit",
  hourCycle: "h23",
});

function partsOf(value: Date | string | number): DateParts {
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) throw new Error("Data inválida.");
  const parts = Object.fromEntries(dateTimeFormatter.formatToParts(date).map((part) => [part.type, part.value]));
  return {
    year: Number(parts.year),
    month: Number(parts.month),
    day: Number(parts.day),
    hour: Number(parts.hour),
    minute: Number(parts.minute),
    second: Number(parts.second),
  };
}

function timeZoneOffsetMs(date: Date) {
  const parts = partsOf(date);
  return Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute, parts.second) - date.getTime();
}

function pad(value: number) {
  return String(value).padStart(2, "0");
}

export function formatBrazilDate(value: Date | string | number) {
  return dateFormatter.format(value instanceof Date ? value : new Date(value));
}

export function formatBrazilDateTime(value: Date | string | number) {
  return dateTimeDisplayFormatter.format(value instanceof Date ? value : new Date(value));
}

export function formatBrazilTime(value: Date | string | number) {
  return timeFormatter.format(value instanceof Date ? value : new Date(value));
}

export function brazilDateTimeLocalValue(value: Date | string | number = new Date()) {
  const parts = partsOf(value);
  return `${parts.year}-${pad(parts.month)}-${pad(parts.day)}T${pad(parts.hour)}:${pad(parts.minute)}`;
}

export function brazilDateKey(value: Date | string | number = new Date()) {
  const parts = partsOf(value);
  return `${parts.year}-${pad(parts.month)}-${pad(parts.day)}`;
}

export function isSameBrazilMonth(value: Date | string | number, reference: Date | string | number = new Date()) {
  const current = partsOf(reference);
  const candidate = partsOf(value);
  return current.year === candidate.year && current.month === candidate.month;
}

export function parseBrazilDateTime(value: unknown): Date | null {
  if (typeof value !== "string" || !value.trim()) return null;
  const text = value.trim();
  if (/[zZ]$|[+-]\d{2}:?\d{2}$/.test(text)) {
    const instant = new Date(text);
    return Number.isNaN(instant.getTime()) ? null : instant;
  }

  const match = text.match(/^(\d{4})-(\d{2})-(\d{2})(?:[T\s](\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{1,3}))?)?)?$/);
  if (!match) return null;
  const [, yearText, monthText, dayText, hourText = "00", minuteText = "00", secondText = "00", millisecondsText = "0"] = match;
  const year = Number(yearText);
  const month = Number(monthText);
  const day = Number(dayText);
  const hour = Number(hourText);
  const minute = Number(minuteText);
  const second = Number(secondText);
  const milliseconds = Number(millisecondsText.padEnd(3, "0"));
  const localAsUtc = new Date(Date.UTC(year, month - 1, day, hour, minute, second, milliseconds));
  if (localAsUtc.getUTCFullYear() !== year || localAsUtc.getUTCMonth() !== month - 1 || localAsUtc.getUTCDate() !== day || hour > 23 || minute > 59 || second > 59) return null;

  const initialOffset = timeZoneOffsetMs(localAsUtc);
  const firstCandidate = new Date(localAsUtc.getTime() - initialOffset);
  const finalOffset = timeZoneOffsetMs(firstCandidate);
  return new Date(localAsUtc.getTime() - finalOffset);
}

export function parseBrazilDateBoundary(value: unknown, endOfDay = false) {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
  return parseBrazilDateTime(`${value}T${endOfDay ? "23:59:59.999" : "00:00:00"}`);
}

export function startOfBrazilDay(value: Date | string | number = new Date()) {
  return parseBrazilDateBoundary(brazilDateKey(value));
}

export function startOfBrazilMonth(value: Date | string | number = new Date()) {
  const parts = partsOf(value);
  return parseBrazilDateBoundary(`${parts.year}-${pad(parts.month)}-01`);
}

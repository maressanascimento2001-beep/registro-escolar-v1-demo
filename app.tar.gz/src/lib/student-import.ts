import { createCanvas } from "@napi-rs/canvas";

type PdfTextItem = { str?: string; hasEOL?: boolean };
type ImportedStudent = { callNumber: number | null; fullName: string };

const ignoredWords = new Set([
  "ALUNO", "ALUNOS", "NOME", "MATRÍCULA", "MATRICULA", "PROVA", "SIMULADO",
  "ATIVIDADE", "TRABALHO", "NOTA", "BASE", "FALTAS", "AULAS", "DADAS",
  "TURMA", "ANO",
]);

const ignoredOcrPhrases = [
  "inserir virgulas automaticamente",
  "configuracao da tecla enter",
  "mover verticalmente",
  "para dispensar o aluno",
  "para segunda chamada digite",
  "tempo de sessao",
  "campos em cinza estao bloqueados",
  "digite para dispensar",
];

function decodePdfString(value: string) {
  return value
    .replace(/\\([\\()])/g, "$1")
    .replace(/\\n/g, "\n")
    .replace(/\\r/g, "\r")
    .replace(/\\t/g, "\t")
    .replace(/\\([0-7]{1,3})/g, (_, octal: string) => String.fromCharCode(Number.parseInt(octal, 8)));
}

function extractSimplePdfStrings(buffer: Buffer) {
  const raw = buffer.toString("latin1");
  const values = [
    ...raw.matchAll(/\(([^()]*)\)\s*Tj/g),
    ...raw.matchAll(/\[([^\]]+)\]\s*TJ/g),
  ].flatMap((match) => {
    const value = match[1];
    return match[0].includes("TJ")
      ? [...value.matchAll(/\(([^()]*)\)/g)].map((part) => decodePdfString(part[1]))
      : [decodePdfString(value)];
  });
  return values.join("\n");
}

async function extractPdfJsText(buffer: Buffer) {
  const { getDocument } = await import("pdfjs-dist/legacy/build/pdf.mjs");
  const document = await getDocument({ data: new Uint8Array(buffer), useSystemFonts: true }).promise;
  const lines: string[] = [];
  try {
    for (let pageNumber = 1; pageNumber <= document.numPages; pageNumber += 1) {
      const page = await document.getPage(pageNumber);
      const content = await page.getTextContent();
      let line = "";
      for (const item of content.items as PdfTextItem[]) {
        const part = item.str?.trim() ?? "";
        if (part) line = line ? `${line} ${part}` : part;
        if (item.hasEOL && line) {
          lines.push(line);
          line = "";
        }
      }
      if (line) lines.push(line);
      page.cleanup();
    }
  } finally {
    document.cleanup();
  }
  return lines.join("\n");
}

type OcrWorker = {
  recognize: (image: Buffer) => Promise<{ data: { text: string } }>;
  terminate: () => Promise<unknown>;
};

let ocrWorkerPromise: Promise<OcrWorker> | null = null;

async function getOcrWorker() {
  if (!ocrWorkerPromise) {
    ocrWorkerPromise = import("tesseract.js").then(({ createWorker }) => createWorker("por", 1, {
      langPath: "https://tessdata.projectnaptha.com/4.0.0",
      logger: () => undefined,
    }));
  }
  return ocrWorkerPromise;
}

async function extractOcrText(buffer: Buffer) {
  const { getDocument } = await import("pdfjs-dist/legacy/build/pdf.mjs");
  const document = await getDocument({ data: new Uint8Array(buffer), useSystemFonts: true }).promise;
  const worker = await getOcrWorker();
  const pages: string[] = [];
  try {
    const pageLimit = Math.min(document.numPages, 12);
    for (let pageNumber = 1; pageNumber <= pageLimit; pageNumber += 1) {
      const page = await document.getPage(pageNumber);
      const viewport = page.getViewport({ scale: 2 });
      const canvas = createCanvas(Math.ceil(viewport.width), Math.ceil(viewport.height));
      const context = canvas.getContext("2d");
      await page.render({ canvas: canvas as unknown as HTMLCanvasElement, canvasContext: context as unknown as CanvasRenderingContext2D, viewport } as never).promise;
      const result = await worker.recognize(canvas.toBuffer("image/png"));
      if (result.data.text.trim()) pages.push(result.data.text);
      page.cleanup();
    }
  } finally {
    document.cleanup();
  }
  return pages.join("\n");
}

function normalizeLine(line: string) {
  return line.replace(/[|]+/g, " ").replace(/\s+/g, " ").trim();
}

function foldText(value: string) {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("pt-BR");
}

function parseStudentLine(line: string): ImportedStudent | null {
  const normalized = normalizeLine(line);
  const folded = foldText(normalized);
  if (!normalized || normalized.length > 160 || ignoredOcrPhrases.some((phrase) => folded.includes(phrase)) || /^(nome|aluno|lista|turma|ano|n[ºo°]|número|matr[ií]cula)/i.test(normalized)) return null;

  const leadingNumber = normalized.match(/^(\d{1,3})[ºo°\s.)-]+(.+)$/i);
  const callNumber = leadingNumber ? Number(leadingNumber[1]) : null;
  let rest = leadingNumber?.[2] ?? normalized;
  rest = rest.replace(/^\d{5,}\s+/, "");
  const tokens = rest.split(" ");
  const nameTokens: string[] = [];
  for (const token of tokens) {
    const upper = token.toLocaleUpperCase("pt-BR");
    if (nameTokens.length >= 2 && (ignoredWords.has(upper) || /^\d+$/.test(token))) break;
    nameTokens.push(token);
  }
  const fullName = nameTokens.join(" ").trim();
  const letters = fullName.replace(/[^A-Za-zÀ-ÖØ-öø-ÿ]/g, "");
  const nameWords = fullName.split(/\s+/).filter((word) => /[A-Za-zÀ-ÖØ-öø-ÿ]/.test(word));
  const blockedNameWords = ["inserir", "virgulas", "automaticamente", "configuracao", "tecla", "enter", "mover", "verticalmente", "dispensar", "segunda", "chamada", "digite", "tempo", "sessao", "campos", "cinza", "bloqueados"];
  if (letters.length < 3 || nameWords.length < 2 || blockedNameWords.some((word) => nameWords.some((nameWord) => foldText(nameWord).replace(/[^a-z]/g, "") === word)) || ignoredWords.has(fullName.toLocaleUpperCase("pt-BR"))) return null;
  return { callNumber, fullName };
}

export function parseImportedStudents(text: string) {
  const students = text
    .split(/\r?\n/)
    .map(parseStudentLine)
    .filter((item): item is ImportedStudent => Boolean(item));
  return students.filter((item, index, all) => all.findIndex((other) => other.fullName.toLocaleLowerCase() === item.fullName.toLocaleLowerCase()) === index);
}

export async function extractStudentsFromPdf(buffer: Buffer) {
  const rawText = extractSimplePdfStrings(buffer);
  let text = rawText;
  if (!text.trim()) {
    try {
      text = await extractPdfJsText(buffer);
    } catch {
      text = "";
    }
  }
  let students = parseImportedStudents(text);
  if (!students.length) {
    const ocrText = await extractOcrText(buffer);
    text = [text, ocrText].filter(Boolean).join("\n");
    students = parseImportedStudents(ocrText);
  }
  return { text, students };
}

import type { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";

import { prisma } from "@/lib/prisma";
import { verifyPassword } from "@/lib/password";

const demoEmail = (process.env.DEMO_PROFESSOR_EMAIL ?? "professor@registroescolar.local").trim().toLowerCase();
const demoPassword = process.env.DEMO_PROFESSOR_PASSWORD;

export const authOptions: NextAuthOptions = {
  secret: process.env.NEXTAUTH_SECRET,
  session: { strategy: "jwt" },
  pages: { signIn: "/login" },
  providers: [
    CredentialsProvider({
      name: "Professor",
      credentials: {
        email: { label: "E-mail", type: "email" },
        password: { label: "Senha", type: "password" },
      },
      async authorize(credentials) {
        const email = typeof credentials?.email === "string" ? credentials.email.trim().toLowerCase() : "";
        const password = typeof credentials?.password === "string" ? credentials.password : "";
        if (!email || !password) return null;

        const user = await prisma.user.findUnique({ where: { email } });
        if (user?.passwordHash) {
          if (!(await verifyPassword(password, user.passwordHash))) return null;
          return { id: user.id, name: user.name, email: user.email, role: user.role };
        }

        if (email !== demoEmail || !demoPassword || password !== demoPassword) return null;

        return {
          id: user?.id ?? "sprint-1-professor",
          name: user?.name ?? "Professor",
          email: demoEmail,
          role: "PROFESSOR",
        };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) token.role = user.role;
      return token;
    },
    async session({ session, token }) {
      if (session.user) session.user.role = token.role as string;
      return session;
    },
  },
};

import type { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";

const demoEmail = process.env.DEMO_PROFESSOR_EMAIL ?? "professor@registroescolar.local";
const demoPassword = process.env.DEMO_PROFESSOR_PASSWORD;

export const authOptions: NextAuthOptions = {
  secret: process.env.NEXTAUTH_SECRET,
  session: { strategy: "jwt" },
  pages: { signIn: "/login" },
  providers: [
    CredentialsProvider({
      name: "Professor",
      credentials: {
        email: { label: "E-mail", type: "email" },
        password: { label: "Senha", type: "password" },
      },
      async authorize(credentials) {
        if (credentials?.email !== demoEmail || credentials?.password !== demoPassword) {
          return null;
        }

        return {
          id: "sprint-1-professor",
          name: "Professor",
          email: demoEmail,
          role: "PROFESSOR",
        };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) token.role = user.role;
      return token;
    },
    async session({ session, token }) {
      if (session.user) session.user.role = token.role as string;
      return session;
    },
  },
};

import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const catalog = {
  "Pedagógico": [
    "Não realizou a atividade em sala",
    "Não entregou o trabalho",
    "Não entregou a atividade de casa",
    "Não realizou a produção de texto",
  ],
  Comportamento: [
    "Indisciplina",
    "Conversa excessiva",
    "Desrespeito",
    "Descumprimento dos combinados",
    "Uso inadequado do celular",
    "Atrapalhou o andamento da aula",
    "Conflito com colegas",
    "Recusou-se a cumprir a orientação",
  ],
  Materiais: [
    "Esqueceu o material",
    "Material incompleto",
    "Não trouxe o caderno",
    "Não trouxe o livro",
    "Não trouxe o material solicitado",
    "Não trouxe a atividade",
  ],
  "Frequência": ["Falta", "Atraso", "Saída antecipada", "Ausência em parte da aula"],
  "Avaliações": [
    "Não realizou a avaliação",
    "Não entregou a avaliação",
    "Entregou a avaliação em branco",
    "Necessitou de atendimento individual",
    "Não concluiu a avaliação",
    "Ausente no dia da avaliação",
  ],
  Elogios: [
    "Participação",
    "Colaboração",
    "Evolução",
    "Organização",
    "Bom desempenho",
    "Comprometimento",
    "Realizou todas as atividades",
    "Demonstrou respeito",
    "Ajudou os colegas",
    "Excelente comportamento",
  ],
  Outros: ["Outra situação"],
};

async function getOrCreateStudent(fullName) {
  return prisma.student.upsert({
    where: { id: `demo-${fullName.toLowerCase().replaceAll(" ", "-")}` },
    update: { fullName, active: true },
    create: { id: `demo-${fullName.toLowerCase().replaceAll(" ", "-")}`, fullName, active: true },
  });
}

async function main() {
  const institution = await prisma.institution.upsert({
    where: { id: "demo-institution" },
    update: { name: "Escola Registro Escolar" },
    create: { id: "demo-institution", name: "Escola Registro Escolar" },
  });

  const demoEmail = process.env.DEMO_PROFESSOR_EMAIL ?? "professor@registroescolar.local";
  const professor = await prisma.user.upsert({
    where: { email: demoEmail },
    update: { name: "Professora", role: "PROFESSOR", institutionId: institution.id },
    create: { id: "demo-professor", institutionId: institution.id, name: "Professora", email: demoEmail, role: "PROFESSOR" },
  });

  const academicYear = await prisma.academicYear.upsert({
    where: { institutionId_name: { institutionId: institution.id, name: "2026" } },
    update: { identification: "Ano letivo demonstrativo" },
    create: { institutionId: institution.id, name: "2026", identification: "Ano letivo demonstrativo" },
  });

  const disciplines = {};
  for (const name of ["Língua Portuguesa", "Matemática"]) {
    disciplines[name] = await prisma.discipline.upsert({
      where: { institutionId_name: { institutionId: institution.id, name } },
      update: { active: true },
      create: { institutionId: institution.id, name },
    });
  }

  const classA = await prisma.schoolClass.upsert({
    where: { academicYearId_name: { academicYearId: academicYear.id, name: "5º A" } },
    update: { active: true, disciplineId: disciplines["Língua Portuguesa"].id, gradeLevel: "5º ano", shift: "Manhã" },
    create: { academicYearId: academicYear.id, name: "5º A", gradeLevel: "5º ano", shift: "Manhã", disciplineId: disciplines["Língua Portuguesa"].id },
  });
  const classB = await prisma.schoolClass.upsert({
    where: { academicYearId_name: { academicYearId: academicYear.id, name: "5º B" } },
    update: { active: true, disciplineId: disciplines.Matemática.id, gradeLevel: "5º ano", shift: "Manhã" },
    create: { academicYearId: academicYear.id, name: "5º B", gradeLevel: "5º ano", shift: "Manhã", disciplineId: disciplines.Matemática.id },
  });

  const classAStudents = ["Ana Souza", "Beatriz Lima", "Carlos Mendes", "Daniela Rocha", "Eduardo Alves"];
  const classBStudents = ["Fernanda Alves", "Gabriel Costa", "Helena Martins"];
  const studentMap = {};
  for (const [index, name] of classAStudents.entries()) studentMap[name] = await getOrCreateStudent(name);
  for (const [index, name] of classBStudents.entries()) studentMap[name] = await getOrCreateStudent(name);

  for (const [index, name] of classAStudents.entries()) {
    await prisma.enrollment.upsert({ where: { classId_studentId: { classId: classA.id, studentId: studentMap[name].id } }, update: { academicYearId: academicYear.id, callNumber: index + 1, endedAt: null }, create: { academicYearId: academicYear.id, classId: classA.id, studentId: studentMap[name].id, callNumber: index + 1 } });
  }
  for (const [index, name] of classBStudents.entries()) {
    await prisma.enrollment.upsert({ where: { classId_studentId: { classId: classB.id, studentId: studentMap[name].id } }, update: { academicYearId: academicYear.id, callNumber: index + 1, endedAt: null }, create: { academicYearId: academicYear.id, classId: classB.id, studentId: studentMap[name].id, callNumber: index + 1 } });
  }

  const categories = {};
  for (const name of Object.keys(catalog)) {
    categories[name] = await prisma.recordCategory.upsert({ where: { name }, update: {}, create: { name } });
    for (const typeName of catalog[name]) await prisma.recordType.upsert({ where: { categoryId_name: { categoryId: categories[name].id, name: typeName } }, update: { active: true }, create: { categoryId: categories[name].id, name: typeName } });
  }

  await prisma.systemSetting.upsert({ where: { institutionId_key: { institutionId: institution.id, key: "activeAcademicYearId" } }, update: { value: academicYear.id }, create: { institutionId: institution.id, key: "activeAcademicYearId", value: academicYear.id } });

  const seededCount = await prisma.record.count({ where: { createdById: professor.id } });
  if (seededCount === 0) {
    const samples = [
      ["Ana Souza", "Pedagógico", "Não realizou a atividade em sala", "A atividade foi retomada com orientação individual."],
      ["Beatriz Lima", "Pedagógico", "Não entregou o trabalho", "Trabalho pendente na data combinada."],
      ["Carlos Mendes", "Pedagógico", "Não entregou a atividade de casa", "Atividade não apresentada."],
      ["Daniela Rocha", "Pedagógico", "Não realizou a produção de texto", "Produção será retomada."],
      ["Eduardo Alves", "Comportamento", "Indisciplina", "Foi necessário retomar os combinados da aula."],
      ["Ana Souza", "Materiais", "Esqueceu o material", "Utilizou material compartilhado."],
      ["Beatriz Lima", "Frequência", "Atraso", "Entrada registrada após o início da aula."],
      ["Carlos Mendes", "Avaliações", "Não realizou a avaliação", "Avaliação reagendada."],
      ["Daniela Rocha", "Elogios", "Participação", "Participou ativamente da discussão."],
      ["Eduardo Alves", "Outros", "Outra situação", "Demonstrou uma situação que precisou de acompanhamento e conversa com a professora."],
    ];
    for (const [studentName, categoryName, typeName, observations] of samples) {
      const type = await prisma.recordType.findFirst({ where: { name: typeName, category: { name: categoryName } } });
      const enrollment = await prisma.enrollment.findFirst({ where: { studentId: studentMap[studentName].id, endedAt: null }, include: { class: true } });
      if (type && enrollment) await prisma.record.create({ data: { academicYearId: academicYear.id, classId: enrollment.classId, studentId: enrollment.studentId, categoryId: type.categoryId, recordTypeId: type.id, observations, createdById: professor.id, recordedAt: new Date() } });
    }
  }

  console.log(`Seed concluído: ${institution.name} · Professor ${demoEmail} · Ano ${academicYear.name}`);
}

main().catch((error) => { console.error(error); process.exitCode = 1; }).finally(async () => prisma.$disconnect());

-- CreateSchema
CREATE SCHEMA IF NOT EXISTS "public";

-- CreateEnum
CREATE TYPE "public"."UserRole" AS ENUM ('PROFESSOR');

-- CreateEnum
CREATE TYPE "public"."ImportMode" AS ENUM ('ADD_ONLY', 'REPLACE_CLASS_LIST');

-- CreateEnum
CREATE TYPE "public"."EntryMode" AS ENUM ('NORMAL', 'QUICK');

-- CreateEnum
CREATE TYPE "public"."RecordScope" AS ENUM ('SINGLE', 'MULTIPLE', 'CLASS');

-- CreateTable
CREATE TABLE "public"."Institution" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "Institution_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."User" (
    "id" TEXT NOT NULL,
    "institutionId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "role" "public"."UserRole" NOT NULL DEFAULT 'PROFESSOR',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "User_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."system_settings" (
    "id" TEXT NOT NULL,
    "institutionId" TEXT NOT NULL,
    "key" TEXT NOT NULL,
    "value" JSONB NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "system_settings_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."academic_years" (
    "id" TEXT NOT NULL,
    "institutionId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "identification" TEXT,
    "startsAt" TIMESTAMP(3),
    "endsAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "academic_years_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."disciplines" (
    "id" TEXT NOT NULL,
    "institutionId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "disciplines_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."classes" (
    "id" TEXT NOT NULL,
    "academicYearId" TEXT NOT NULL,
    "disciplineId" TEXT,
    "name" TEXT NOT NULL,
    "gradeLevel" TEXT,
    "shift" TEXT,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "archivedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "classes_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."students" (
    "id" TEXT NOT NULL,
    "fullName" TEXT NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "students_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."enrollments" (
    "id" TEXT NOT NULL,
    "academicYearId" TEXT NOT NULL,
    "classId" TEXT NOT NULL,
    "studentId" TEXT NOT NULL,
    "callNumber" INTEGER,
    "enrolledAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "endedAt" TIMESTAMP(3),
    CONSTRAINT "enrollments_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."import_batches" (
    "id" TEXT NOT NULL,
    "classId" TEXT NOT NULL,
    "originalName" TEXT NOT NULL,
    "importMode" "public"."ImportMode",
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "import_batches_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."import_items" (
    "id" TEXT NOT NULL,
    "importBatchId" TEXT NOT NULL,
    "studentId" TEXT,
    "extractedName" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "import_items_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."record_categories" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    CONSTRAINT "record_categories_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."record_types" (
    "id" TEXT NOT NULL,
    "categoryId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,
    CONSTRAINT "record_types_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."records" (
    "id" TEXT NOT NULL,
    "academicYearId" TEXT NOT NULL,
    "classId" TEXT NOT NULL,
    "studentId" TEXT NOT NULL,
    "categoryId" TEXT NOT NULL,
    "recordTypeId" TEXT,
    "recordedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "observations" TEXT,
    "customText" TEXT,
    "entryMode" "public"."EntryMode" NOT NULL DEFAULT 'NORMAL',
    "scopeMode" "public"."RecordScope" NOT NULL DEFAULT 'SINGLE',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "createdById" TEXT,
    CONSTRAINT "records_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."user_favorite_record_types" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "recordTypeId" TEXT NOT NULL,
    "position" INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT "user_favorite_record_types_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "User_email_key" ON "public"."User"("email");
CREATE UNIQUE INDEX "system_settings_institutionId_key_key" ON "public"."system_settings"("institutionId", "key");
CREATE UNIQUE INDEX "academic_years_institutionId_name_key" ON "public"."academic_years"("institutionId", "name");
CREATE UNIQUE INDEX "disciplines_institutionId_name_key" ON "public"."disciplines"("institutionId", "name");
CREATE INDEX "classes_academicYearId_idx" ON "public"."classes"("academicYearId");
CREATE UNIQUE INDEX "classes_academicYearId_name_key" ON "public"."classes"("academicYearId", "name");
CREATE INDEX "students_fullName_idx" ON "public"."students"("fullName");
CREATE INDEX "enrollments_academicYearId_classId_idx" ON "public"."enrollments"("academicYearId", "classId");
CREATE UNIQUE INDEX "enrollments_classId_studentId_key" ON "public"."enrollments"("classId", "studentId");
CREATE INDEX "import_batches_classId_idx" ON "public"."import_batches"("classId");
CREATE UNIQUE INDEX "record_categories_name_key" ON "public"."record_categories"("name");
CREATE UNIQUE INDEX "record_types_categoryId_name_key" ON "public"."record_types"("categoryId", "name");
CREATE INDEX "records_studentId_recordedAt_idx" ON "public"."records"("studentId", "recordedAt");
CREATE INDEX "records_classId_recordedAt_idx" ON "public"."records"("classId", "recordedAt");
CREATE INDEX "user_favorite_record_types_userId_position_idx" ON "public"."user_favorite_record_types"("userId", "position");
CREATE UNIQUE INDEX "user_favorite_record_types_userId_recordTypeId_key" ON "public"."user_favorite_record_types"("userId", "recordTypeId");

-- AddForeignKey
ALTER TABLE "public"."User" ADD CONSTRAINT "User_institutionId_fkey" FOREIGN KEY ("institutionId") REFERENCES "public"."Institution"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "public"."system_settings" ADD CONSTRAINT "system_settings_institutionId_fkey" FOREIGN KEY ("institutionId") REFERENCES "public"."Institution"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "public"."academic_years" ADD CONSTRAINT "academic_years_institutionId_fkey" FOREIGN KEY ("institutionId") REFERENCES "public"."Institution"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "public"."disciplines" ADD CONSTRAINT "disciplines_institutionId_fkey" FOREIGN KEY ("institutionId") REFERENCES "public"."Institution"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "public"."classes" ADD CONSTRAINT "classes_academicYearId_fkey" FOREIGN KEY ("academicYearId") REFERENCES "public"."academic_years"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "public"."classes" ADD CONSTRAINT "classes_disciplineId_fkey" FOREIGN KEY ("disciplineId") REFERENCES "public"."disciplines"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "public"."enrollments" ADD CONSTRAINT "enrollments_academicYearId_fkey" FOREIGN KEY ("academicYearId") REFERENCES "public"."academic_years"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "public"."enrollments" ADD CONSTRAINT "enrollments_classId_fkey" FOREIGN KEY ("classId") REFERENCES "public"."classes"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "public"."enrollments" ADD CONSTRAINT "enrollments_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "public"."students"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "public"."import_batches" ADD CONSTRAINT "import_batches_classId_fkey" FOREIGN KEY ("classId") REFERENCES "public"."classes"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "public"."import_items" ADD CONSTRAINT "import_items_importBatchId_fkey" FOREIGN KEY ("importBatchId") REFERENCES "public"."import_batches"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "public"."import_items" ADD CONSTRAINT "import_items_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "public"."students"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "public"."record_types" ADD CONSTRAINT "record_types_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "public"."record_categories"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "public"."records" ADD CONSTRAINT "records_academicYearId_fkey" FOREIGN KEY ("academicYearId") REFERENCES "public"."academic_years"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "public"."records" ADD CONSTRAINT "records_classId_fkey" FOREIGN KEY ("classId") REFERENCES "public"."classes"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "public"."records" ADD CONSTRAINT "records_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "public"."students"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "public"."records" ADD CONSTRAINT "records_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "public"."record_categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "public"."records" ADD CONSTRAINT "records_recordTypeId_fkey" FOREIGN KEY ("recordTypeId") REFERENCES "public"."record_types"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "public"."records" ADD CONSTRAINT "records_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "public"."User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "public"."user_favorite_record_types" ADD CONSTRAINT "user_favorite_record_types_userId_fkey" FOREIGN KEY ("userId") REFERENCES "public"."User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "public"."user_favorite_record_types" ADD CONSTRAINT "user_favorite_record_types_recordTypeId_fkey" FOREIGN KEY ("recordTypeId") REFERENCES "public"."record_types"("id") ON DELETE CASCADE ON UPDATE CASCADE;

const fs = require('fs');
const path = 'C:/Users/Usuário/.codex/visualizations/2026/07/27/019fa41d-7b79-7b70-a9c7-c0d37c8506df/registro-escolar-wireframes.html';
const html = fs.readFileSync(path, 'utf8');
const start = html.indexOf('<script>') + '<script>'.length;
const end = html.indexOf('</script>');
if (start < '<script>'.length || end < 0) throw new Error('script not found');
new Function(html.slice(start, end));
console.log('javascript_syntax OK');

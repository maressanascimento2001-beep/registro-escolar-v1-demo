from pathlib import Path
from datetime import date

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(r"C:\Users\Usuário\Documents\Codex\2026-07-27\quero-desenvolver-um-software-web-chamado")
OUT = ROOT / "outputs" / "registro-escolar-documentacao-tecnica-v1.docx"
OUT.parent.mkdir(parents=True, exist_ok=True)


BLUE = "2E74B5"
DARK_BLUE = "1F4D78"
INK = "0B2545"
MUTED = "5B6573"
LIGHT_GRAY = "F2F4F7"
CALLOUT = "F4F6F9"
PALE_BLUE = "E8EEF5"
WHITE = "FFFFFF"
RED = "9B1C1C"
GOLD = "7A5A00"


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=80, start=120, bottom=80, end=120):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for m, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{m}"))
        if node is None:
            node = OxmlElement(f"w:{m}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_table_geometry(table, widths, indent=120):
    table.autofit = False
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    total = sum(widths)
    tbl = table._tbl
    tbl_pr = tbl.tblPr

    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), str(total))
    tbl_w.set(qn("w:type"), "dxa")

    tbl_ind = tbl_pr.find(qn("w:tblInd"))
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), str(indent))
    tbl_ind.set(qn("w:type"), "dxa")

    grid = tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(width))
        grid.append(col)

    for row in table.rows:
        for idx, cell in enumerate(row.cells):
            width = widths[min(idx, len(widths) - 1)]
            cell.width = Inches(width / 1440)
            tc_pr = cell._tc.get_or_add_tcPr()
            tc_w = tc_pr.find(qn("w:tcW"))
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                tc_pr.append(tc_w)
            tc_w.set(qn("w:w"), str(width))
            tc_w.set(qn("w:type"), "dxa")
            set_cell_margins(cell)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def set_repeat_table_header(row):
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def set_run_font(run, name="Calibri", size=11, color="000000", bold=None, italic=None):
    run.font.name = name
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), name)
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), name)
    run.font.size = Pt(size)
    run.font.color.rgb = RGBColor.from_string(color)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic


def set_paragraph_border_bottom(paragraph, color="B7C3D0", size="8", space="1"):
    p = paragraph._p
    p_pr = p.get_or_add_pPr()
    borders = p_pr.find(qn("w:pBdr"))
    if borders is None:
        borders = OxmlElement("w:pBdr")
        p_pr.append(borders)
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), size)
    bottom.set(qn("w:space"), space)
    bottom.set(qn("w:color"), color)
    borders.append(bottom)


def set_paragraph_shading(paragraph, fill):
    p_pr = paragraph._p.get_or_add_pPr()
    shd = p_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        p_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_paragraph_border_left(paragraph, color="B7C3D0", size="18", space="8"):
    p_pr = paragraph._p.get_or_add_pPr()
    borders = p_pr.find(qn("w:pBdr"))
    if borders is None:
        borders = OxmlElement("w:pBdr")
        p_pr.append(borders)
    left = OxmlElement("w:left")
    left.set(qn("w:val"), "single")
    left.set(qn("w:sz"), size)
    left.set(qn("w:space"), space)
    left.set(qn("w:color"), color)
    borders.append(left)


def add_page_number(paragraph):
    run = paragraph.add_run()
    fld_char1 = OxmlElement("w:fldChar")
    fld_char1.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = "PAGE"
    fld_char2 = OxmlElement("w:fldChar")
    fld_char2.set(qn("w:fldCharType"), "end")
    run._r.append(fld_char1)
    run._r.append(instr)
    run._r.append(fld_char2)


def add_text(paragraph, text, bold=False, italic=False, color="000000", size=11):
    run = paragraph.add_run(text)
    set_run_font(run, size=size, color=color, bold=bold, italic=italic)
    return run


def add_para(doc, text="", bold_prefix=None, color="000000", after=6, before=0, align=None, size=11, italic=False):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(before)
    p.paragraph_format.space_after = Pt(after)
    p.paragraph_format.line_spacing = 1.10
    if align is not None:
        p.alignment = align
    if bold_prefix and text.startswith(bold_prefix):
        add_text(p, bold_prefix, bold=True, color=color, size=size)
        add_text(p, text[len(bold_prefix):], color=color, size=size, italic=italic)
    else:
        add_text(p, text, color=color, size=size, italic=italic)
    return p


def add_bullet(doc, text, level=0):
    p = doc.add_paragraph(style="RE Bullet" if level == 0 else "RE Bullet 2")
    p.paragraph_format.left_indent = Inches(0.5 + level * 0.25)
    p.paragraph_format.first_line_indent = Inches(-0.25)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.167
    add_text(p, text)
    return p


def add_number(doc, text):
    p = doc.add_paragraph(style="RE Number")
    p.paragraph_format.left_indent = Inches(0.5)
    p.paragraph_format.first_line_indent = Inches(-0.25)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.167
    add_text(p, text)
    return p


def add_heading(doc, text, level=1):
    p = doc.add_paragraph(style=f"Heading {level}")
    p.paragraph_format.keep_with_next = True
    add_text(p, text, bold=True, color=BLUE if level < 3 else DARK_BLUE, size={1: 16, 2: 13, 3: 12}[level])
    return p


def add_callout(doc, title, body, fill=CALLOUT, title_color=INK):
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.08)
    p.paragraph_format.right_indent = Inches(0.08)
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.line_spacing = 1.10
    set_paragraph_shading(p, fill)
    set_paragraph_border_left(p, color=title_color)
    add_text(p, title + ": ", bold=True, color=title_color)
    add_text(p, body, color="273142")


def add_table(doc, headers, rows, widths, header_fill=LIGHT_GRAY, font_size=9.5):
    table = doc.add_table(rows=1, cols=len(headers))
    set_table_geometry(table, widths)
    hdr = table.rows[0]
    set_repeat_table_header(hdr)
    for idx, value in enumerate(headers):
        cell = hdr.cells[idx]
        set_cell_shading(cell, header_fill)
        p = cell.paragraphs[0]
        p.paragraph_format.space_after = Pt(0)
        add_text(p, value, bold=True, color=INK, size=font_size)
    for row_values in rows:
        row = table.add_row()
        for idx, value in enumerate(row_values):
            cell = row.cells[idx]
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            add_text(p, str(value), color="202630", size=font_size)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return table


def add_code_line(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.25)
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.line_spacing = 1.0
    run = p.add_run(text)
    set_run_font(run, name="Consolas", size=9, color=INK)
    return p


def configure_styles(doc):
    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Calibri"
    normal._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
    normal._element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
    normal.font.size = Pt(11)
    normal.font.color.rgb = RGBColor.from_string("000000")
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.10

    for name, size, color, before, after in [
        ("Heading 1", 16, BLUE, 16, 8),
        ("Heading 2", 13, BLUE, 12, 6),
        ("Heading 3", 12, DARK_BLUE, 8, 4),
    ]:
        style = styles[name]
        style.font.name = "Calibri"
        style._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
        style._element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor.from_string(color)
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True

    for name, base in [("RE Bullet", "List Bullet"), ("RE Bullet 2", "List Bullet 2"), ("RE Number", "List Number")]:
        if name not in styles:
            style = styles.add_style(name, 1)
            style.base_style = styles[base]
        style = styles[name]
        style.font.name = "Calibri"
        style._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
        style._element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
        style.font.size = Pt(11)
        style.paragraph_format.space_after = Pt(4)
        style.paragraph_format.line_spacing = 1.167


def configure_section(section):
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)

    header = section.header
    hp = header.paragraphs[0]
    hp.alignment = WD_ALIGN_PARAGRAPH.LEFT
    hp.paragraph_format.space_after = Pt(2)
    add_text(hp, "Registro Escolar | Documentação técnica v1", color=MUTED, size=9)
    set_paragraph_border_bottom(hp, color="D7DEE8", size="6", space="1")

    footer = section.footer
    fp = footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    fp.paragraph_format.space_before = Pt(2)
    add_text(fp, "Documento para aprovação | Página ", color=MUTED, size=9)
    add_page_number(fp)
    for run in fp.runs:
        set_run_font(run, size=9, color=MUTED)


def build_document():
    doc = Document()
    configure_styles(doc)
    for section in doc.sections:
        configure_section(section)

    # Capa / masthead
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(30)
    p.paragraph_format.space_after = Pt(5)
    add_text(p, "DOCUMENTAÇÃO TÉCNICA", bold=True, color=BLUE, size=11)
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(8)
    add_text(p, "Registro Escolar", bold=True, color=INK, size=28)
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(18)
    add_text(p, "Especificação arquitetural e funcional da versão 1", color=MUTED, size=15)

    metadata = [
        ("Status", "Versão revisada para aprovação"),
        ("Escopo", "Versão 1 - registros escolares, alunos, turmas e relatórios"),
        ("Perfil", "Professor com acesso completo"),
        ("Atualização", "Duplicação de ano, importação por modo, registro rápido, backup e contexto"),
        ("Data", date.today().strftime("%d/%m/%Y")),
    ]
    add_table(doc, ["Item", "Definição"], metadata, [2100, 7260], header_fill=PALE_BLUE, font_size=10)
    add_callout(
        doc,
        "Objetivo deste documento",
        "Registrar a arquitetura, os requisitos e os critérios de aceite antes da implementação. Este documento não contém código de aplicação.",
    )

    doc.add_page_break()

    add_heading(doc, "Sumário", 1)
    summary_items = [
        "1. Visão geral e objetivo",
        "2. Escopo funcional da versão 1",
        "3. Regras de negócio e catálogo de registros",
        "4. Telas e fluxos de navegação",
        "5. Modelo de dados e relacionamentos",
        "6. Estrutura das APIs",
        "7. Arquitetura e tecnologias",
        "8. Organização de pastas",
        "9. Segurança, backup e restauração",
        "10. Cronograma de desenvolvimento",
        "11. Critérios de aceite",
        "12. Expansões futuras",
    ]
    for item in summary_items:
        add_bullet(doc, item)

    add_heading(doc, "1. Visão geral e objetivo", 1)
    add_para(doc, "O Registro Escolar é uma aplicação web para que Professores registrem e consultem informações relacionadas à rotina dos alunos. O sistema organiza registros pedagógicos, comportamentais, materiais, frequência, avaliações, elogios e anotações personalizadas.")
    add_para(doc, "A versão 1 prioriza rapidez durante a aula, baixo número de cliques, manutenção simples e consistência histórica. A terminologia oficial do sistema é Registro.")
    add_callout(doc, "Decisão de escopo", "Existe somente o perfil Professor. Todo Professor autenticado possui acesso completo às turmas, alunos, registros, relatórios, configurações e operações de backup.")

    add_heading(doc, "2. Escopo funcional da versão 1", 1)
    add_heading(doc, "2.1 Autenticação e perfil", 2)
    for item in [
        "Login obrigatório para acesso ao sistema.",
        "Um único perfil: Professor.",
        "Todos os Professores possuem as mesmas permissões funcionais.",
        "Dados de autenticação são incluídos no backup, sem expor senhas em texto puro.",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "2.2 Ano letivo", 2)
    for item in [
        "Cadastro, edição e consulta de anos letivos.",
        "Toda turma pertence obrigatoriamente a um ano letivo.",
        "O mesmo nome de turma pode existir em anos letivos diferentes.",
        "Duplicação de ano letivo copia apenas a estrutura das turmas.",
        "Relatórios, filtros, pesquisas e contexto de trabalho consideram o ano letivo.",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "2.3 Disciplinas", 2)
    for item in [
        "Cadastro de uma ou mais disciplinas.",
        "Cada turma pode ter uma disciplina vinculada.",
        "A disciplina é exibida nos relatórios.",
        "A exclusão de disciplina vinculada a turmas é bloqueada.",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "2.4 Turmas", 2)
    for item in [
        "Criar, editar, consultar e excluir turma.",
        "Informar nome, série ou etapa, turno, ano letivo obrigatório e disciplina opcional.",
        "Visualizar alunos matriculados.",
        "Importar alunos por PDF.",
        "Registrar para aluno individual, vários alunos ou toda a turma.",
        "Duplicar o ano letivo para gerar as turmas do próximo período sem alunos ou registros.",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "2.5 Alunos e matrículas", 2)
    for item in [
        "Importação de alunos por PDF textual com revisão simples.",
        "Modo Adicionar apenas novos alunos.",
        "Modo Substituir a lista atual de alunos da turma.",
        "Cadastro manual, edição, exclusão e pesquisa por nome.",
        "Um aluno pode estar matriculado em várias turmas.",
        "Número da chamada opcional, armazenado por matrícula e exibido na lista da turma.",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "2.6 Registros", 2)
    for item in [
        "Registro individual.",
        "Registro para vários alunos selecionados.",
        "Registro para toda a turma, criando uma linha individual por aluno no momento da operação.",
        "Registro personalizado com texto livre.",
        "Registro Rápido diretamente na lista de alunos usando tipos favoritos.",
        "Edição e exclusão lógica sem histórico de versões na v1.",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "2.7 Histórico", 2)
    add_para(doc, "A ficha do aluno apresenta todos os registros em ordem cronológica decrescente, sem agrupamento obrigatório por categoria. O Professor pode aplicar filtros por categoria, ano letivo e período.")

    add_heading(doc, "2.8 Dashboard", 2)
    for item in [
        "Total de turmas no contexto do ano letivo.",
        "Total de alunos distintos matriculados no contexto.",
        "Registros realizados hoje.",
        "Registros realizados no mês.",
        "Últimos registros.",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "2.9 Relatórios", 2)
    for item in [
        "Relatório individual do aluno.",
        "Relatório consolidado da turma.",
        "Filtros por aluno, turma, ano letivo e período.",
        "Ordenação por data ou por categoria.",
        "PDF em folha A4.",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "2.10 Backup e restauração", 2)
    for item in [
        "Exportar backup em arquivo compactado próprio do sistema.",
        "Restaurar backup com validação de formato, versão e integridade.",
        "Restauração integral, sem mesclagem, com confirmação explícita.",
        "Rollback transacional se a restauração falhar.",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "3. Regras de negócio e catálogo de registros", 1)
    add_heading(doc, "3.1 Contexto de trabalho", 2)
    add_para(doc, "O contexto é composto por Ano Letivo obrigatório e Turma opcional. A opção Todas as turmas permite consultas amplas dentro do ano selecionado. O contexto é mantido pela aplicação e enviado às operações que dependem de ano ou turma.")
    add_heading(doc, "3.2 Duplicação de ano letivo", 2)
    add_number(doc, "Selecionar o ano letivo de origem.")
    add_number(doc, "Informar o novo ano letivo e, se necessário, suas datas.")
    add_number(doc, "Validar que o novo ano não existe.")
    add_number(doc, "Criar o novo ano letivo.")
    add_number(doc, "Copiar nome, série ou etapa, turno e disciplina das turmas.")
    add_number(doc, "Criar as novas turmas sem alunos, matrículas, números de chamada ou registros.")
    add_number(doc, "Confirmar a operação em uma transação única.")
    add_callout(doc, "Regra de integridade", "Se qualquer etapa da duplicação falhar, o novo ano e todas as turmas criadas deverão ser desfeitos.", fill="FFF8E8", title_color=GOLD)

    add_heading(doc, "3.3 Importação de alunos", 2)
    add_number(doc, "Enviar o PDF da turma.")
    add_number(doc, "Extrair e visualizar os nomes encontrados.")
    add_number(doc, "Escolher Adicionar apenas novos alunos ou Substituir a lista atual de alunos da turma.")
    add_number(doc, "Confirmar a importação.")
    add_para(doc, "No modo de adição, as matrículas atuais permanecem. No modo de substituição, as matrículas atuais da turma são removidas e recriadas a partir do PDF, mas alunos e registros históricos permanecem armazenados. Matrículas em outras turmas não são alteradas.")

    add_heading(doc, "3.4 Registro coletivo", 2)
    add_para(doc, "O Professor pode selecionar um aluno, vários alunos ou toda a turma. Para o escopo de turma inteira, o sistema captura os alunos matriculados no instante da operação e cria um registro individual para cada um. Alterações posteriores na turma não modificam o histórico já criado.")

    add_heading(doc, "3.5 Registro Rápido", 2)
    add_para(doc, "Na lista da turma, os tipos favoritos aparecem próximos a cada aluno. O clique em um favorito cria imediatamente um registro individual, usando a turma do contexto, a data atual e o tipo selecionado. O Professor permanece na lista e recebe confirmação visual.")

    add_heading(doc, "3.6 Catálogo de categorias e tipos", 2)
    catalog_rows = [
        ("Pedagógico", "Não fez atividade; Não entregou trabalho; Não trouxe material; Não realizou leitura; Não participou; Não realizou tarefa de casa"),
        ("Comportamento", "Conversa excessiva; Brincadeiras durante a aula; Desrespeitou regras; Interrompeu explicação; Saiu do lugar sem autorização"),
        ("Materiais", "Trouxe brinquedo; Trouxe objeto não pedagógico"),
        ("Frequência", "Falta; Atraso; Saída antecipada"),
        ("Avaliações", "Aplicação de avaliação; Entrega de avaliação; Devolutiva da avaliação; Recuperação aplicada"),
        ("Elogios", "Excelente participação; Excelente comportamento; Ajudou colegas; Destaque na atividade; Demonstrou responsabilidade"),
        ("Personalizados", "Texto livre quando nenhum tipo predefinido atender à necessidade"),
    ]
    add_table(doc, ["Categoria", "Tipos"], catalog_rows, [1900, 7460], font_size=9.2)

    add_heading(doc, "3.7 Registros favoritos", 2)
    add_para(doc, "Cada Professor poderá selecionar e ordenar tipos predefinidos como favoritos. Esses tipos aparecerão antes dos demais no formulário normal e na lista do Registro Rápido. O registro personalizado não é favorito de catálogo, pois depende de texto livre.")

    add_heading(doc, "4. Telas e fluxos de navegação", 1)
    add_heading(doc, "4.1 Estrutura principal", 2)
    add_para(doc, "Login → Dashboard → Turmas | Alunos | Registros | Relatórios | Configurações")
    add_para(doc, "A barra superior permanece visível após o login e contém Pesquisa global, Ano Letivo e Turma.")

    add_heading(doc, "4.2 Fluxos principais", 2)
    flow_rows = [
        ("Criar turma", "Configurações ou Turmas → Nova turma → Ano letivo obrigatório → Disciplina opcional → Salvar"),
        ("Duplicar ano", "Configurações → Anos letivos → Duplicar → Novo ano → Copiar turmas sem alunos → Concluir"),
        ("Importar alunos", "Turma → Importar PDF → Visualizar alunos → Escolher modo → Confirmar"),
        ("Registro normal", "Turma ou aluno → Novo Registro → Escopo → Categoria/tipo → Observações → Salvar"),
        ("Registro Rápido", "Turma → Lista de alunos → Tipo favorito → Registro salvo"),
        ("Histórico", "Pesquisa global ou Alunos → Ficha → Filtros → Histórico de registros"),
        ("Novo pelo histórico", "Ficha do aluno → Novo Registro → Formulário pré-preenchido → Salvar"),
        ("Relatório", "Relatórios → Aluno ou turma → Ano/período → Ordenação → Gerar PDF A4"),
        ("Backup", "Configurações → Exportar Backup → Baixar arquivo"),
        ("Restauração", "Configurações → Restaurar Backup → Validar → Confirmar substituição → Resultado"),
    ]
    add_table(doc, ["Fluxo", "Navegação"], flow_rows, [1900, 7460], font_size=9.2)

    add_heading(doc, "4.3 Pesquisa global", 2)
    add_para(doc, "A barra de pesquisa localizada no topo pesquisa alunos e turmas. Os resultados exibem o ano letivo para evitar ambiguidades. Ao selecionar um aluno, a ficha é aberta diretamente; ao selecionar uma turma, a tela da turma é aberta e o contexto é atualizado.")

    add_heading(doc, "4.4 Lista de alunos da turma", 2)
    add_para(doc, "A lista exibe nome, número da chamada e ações de Registro Rápido. O número da chamada é ordenável e serve apenas para localização operacional dentro da turma.")

    add_heading(doc, "4.5 Histórico do aluno", 2)
    add_para(doc, "O histórico possui o botão Novo Registro e filtros: Todos, Pedagógico, Comportamento, Materiais, Frequência, Avaliações, Elogios, Personalizados, Ano Letivo e período de datas.")

    add_heading(doc, "5. Modelo de dados e relacionamentos", 1)
    add_heading(doc, "5.1 Tabelas", 2)
    db_rows = [
        ("institutions", "Instituição única da instalação; mantém extensibilidade futura.", "id, name, active"),
        ("users", "Professores autenticados; não há diferenciação de perfil na v1.", "id, institution_id, name, email, password_hash, status"),
        ("system_settings", "Configurações básicas da instituição e dos relatórios.", "id, institution_id, key, value"),
        ("academic_years", "Anos letivos aos quais as turmas pertencem.", "id, institution_id, year, label, start_date, end_date, status"),
        ("disciplines", "Catálogo de disciplinas.", "id, institution_id, name, active"),
        ("classes", "Turmas vinculadas obrigatoriamente a um ano letivo.", "id, academic_year_id, discipline_id, name, grade, shift"),
        ("students", "Cadastro institucional de alunos.", "id, institution_id, full_name, status"),
        ("enrollments", "Vínculo aluno-turma e número de chamada.", "id, student_id, class_id, roll_call_number, status, dates"),
        ("import_batches", "Metadados de uma importação de PDF.", "id, class_id, import_mode, source_name, status"),
        ("import_items", "Nomes extraídos e resultado da confirmação.", "id, batch_id, raw_name, student_id, status"),
        ("record_categories", "Categorias fixas do catálogo de registros.", "id, name, active"),
        ("record_types", "Tipos predefinidos de registro.", "id, category_id, name, active"),
        ("records", "Registro individual vinculado a aluno e turma.", "id, student_id, class_id, category_id, type_id, custom_text, observations, record_scope, entry_mode, occurred_at, deleted_at"),
        ("user_favorite_record_types", "Tipos favoritos ordenados por Professor.", "user_id, record_type_id, position"),
    ]
    add_table(doc, ["Tabela", "Responsabilidade", "Campos representativos"], db_rows, [1900, 3700, 3760], font_size=8.8)

    add_heading(doc, "5.2 Relacionamentos", 2)
    relationships = [
        "Uma instituição possui anos letivos, disciplinas, turmas, alunos e Professores.",
        "Um ano letivo possui várias turmas; cada turma possui exatamente um ano letivo.",
        "Uma disciplina pode estar associada a várias turmas; a disciplina da turma é opcional.",
        "Alunos e turmas relacionam-se por enrollments, permitindo múltiplas turmas simultâneas.",
        "O número da chamada pertence à matrícula e é único dentro da turma quando preenchido.",
        "Uma turma possui vários registros; cada registro pertence a um aluno e a uma turma.",
        "Um tipo de registro pertence a uma categoria.",
        "Um Professor possui vários tipos favoritos, com posição de exibição.",
        "Uma importação possui itens extraídos e um modo de execução.",
    ]
    for item in relationships:
        add_bullet(doc, item)

    add_heading(doc, "5.3 Regras de integridade e índices", 2)
    for item in [
        "Índice único para ano letivo por instituição e ano.",
        "Índice de turmas por ano letivo e nome.",
        "Índice parcial de número da chamada por turma.",
        "Índices de registros por aluno/data, turma/data e categoria.",
        "Exclusão lógica de registros; registros excluídos não aparecem nas consultas operacionais.",
        "Duplicação de ano e restauração de backup executadas em transação.",
        "O backend valida que classId pertence ao academicYearId informado.",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "6. Estrutura das APIs", 1)
    add_para(doc, "A API REST será versionada em /api/v1. Respostas utilizarão validação, paginação, filtros, erros padronizados e identificador de requisição.")
    api_rows = [
        ("Autenticação", "POST /auth/login; POST /auth/logout; POST /auth/refresh; GET /auth/me"),
        ("Contexto", "Estado compartilhado da aplicação; requests context-sensitive carregam academicYearId e classId"),
        ("Anos letivos", "GET/POST /academic-years; GET/PATCH/DELETE /academic-years/:id; POST /academic-years/:id/duplicate"),
        ("Disciplinas", "GET/POST /disciplines; GET/PATCH/DELETE /disciplines/:id"),
        ("Turmas", "GET/POST /classes; GET/PATCH/DELETE /classes/:id; GET /classes/:id/students"),
        ("Alunos", "GET/POST /students; GET/PATCH/DELETE /students/:id; PATCH /enrollments/:id"),
        ("Importações", "POST /imports; GET /imports/:id/preview; POST /imports/:id/confirm"),
        ("Registros", "POST/GET /records; GET/PATCH/DELETE /records/:id; GET /students/:id/records"),
        ("Favoritos", "GET/PUT /me/favorite-record-types"),
        ("Pesquisa", "GET /search?q=&academicYearId=&limit="),
        ("Dashboard", "GET /dashboard/summary; GET /dashboard/recent-records"),
        ("Relatórios", "GET /reports/student/:id.pdf; GET /reports/class/:id.pdf"),
        ("Backup", "POST /backups/export; POST /backups/restore"),
    ]
    add_table(doc, ["Domínio", "Endpoints"], api_rows, [1900, 7460], font_size=8.8)

    add_heading(doc, "6.1 Contratos específicos", 2)
    add_code_line(doc, "POST /academic-years/:id/duplicate")
    add_para(doc, "Cria um novo ano e copia as turmas estruturais da origem. Retorna o novo ano e a quantidade de turmas criadas.")
    add_code_line(doc, "POST /imports/:id/confirm")
    add_para(doc, "Recebe importMode=ADD_ONLY ou importMode=REPLACE_CLASS_LIST. No segundo modo, substitui matrículas da turma e preserva registros.")
    add_code_line(doc, "POST /records")
    add_para(doc, "Recebe aluno ou lista de alunos, turma, tipo/categoria, observações, data, record_scope e entry_mode opcional. O Registro Rápido reutiliza este endpoint com entry_mode=QUICK.")
    add_code_line(doc, "GET /reports/student/:studentId.pdf?academicYearId=&classId=&from=&to=&sortBy=DATE|CATEGORY")
    add_code_line(doc, "GET /reports/class/:classId.pdf?academicYearId=&from=&to=&sortBy=DATE|CATEGORY")
    add_para(doc, "Gera PDF A4 após validar contexto e filtros.")
    add_code_line(doc, "POST /backups/restore")
    add_para(doc, "Valida o arquivo, exige confirmação e substitui integralmente os dados atuais em uma transação.")

    add_heading(doc, "7. Arquitetura e tecnologias", 1)
    add_para(doc, "A solução permanecerá como aplicação modular monolítica, reduzindo complexidade operacional e mantendo separação clara por domínio.")
    tech_rows = [
        ("Frontend e servidor web", "Next.js, React e TypeScript"),
        ("Persistência", "PostgreSQL"),
        ("ORM e migrações", "Prisma"),
        ("Autenticação", "Sessão segura ou JWT em cookie HttpOnly; senhas com Argon2id"),
        ("PDF de entrada", "Parser de PDF textual com revisão simples"),
        ("PDF de saída", "PDFKit ou equivalente, folha A4, tabelas e ordenação"),
        ("Backup", "Arquivo compactado próprio com manifesto, dados estruturados e checksum"),
        ("Testes", "Jest, testes de integração e Playwright"),
        ("Infraestrutura", "Docker, banco gerenciado em nuvem, HTTPS e backups operacionais"),
    ]
    add_table(doc, ["Camada", "Recomendação"], tech_rows, [2300, 7060], font_size=9.2)

    add_heading(doc, "8. Organização de pastas", 1)
    for line in [
        "src/",
        "  app/",
        "    login/ dashboard/ turmas/ alunos/ registros/ relatorios/ configuracoes/",
        "    api/v1/",
        "  components/",
        "  modules/",
        "    auth/ dashboard/ academic-years/ disciplines/ classes/ students/ imports/ records/ reports/ backups/ settings/",
        "  lib/",
        "    database/ pdf/ backup/ validation/ context/",
        "  types/",
        "  styles/",
        "prisma/",
        "  schema.prisma migrations/ seed/",
        "tests/",
        "  unit/ integration/ e2e/ fixtures/",
        "docs/",
        "  architecture/ api/ decisions/",
    ]:
        add_code_line(doc, line)
    add_para(doc, "Os módulos usam a terminologia Registro e não possuem uma área administrativa separada. O contexto de trabalho é uma preocupação transversal da aplicação e não uma tabela independente.")

    add_heading(doc, "9. Segurança, backup e restauração", 1)
    add_heading(doc, "9.1 Segurança geral", 2)
    for item in [
        "HTTPS obrigatório e cookies de autenticação com HttpOnly e Secure.",
        "Validação de entradas, proteção contra injeção, XSS e abuso de endpoints.",
        "Controle de sessão e invalidação após restauração.",
        "Logs técnicos sem expor dados desnecessários de alunos.",
        "Backup baixado tratado como arquivo sensível de dados escolares.",
        "Princípios básicos da LGPD e minimização de arquivos temporários.",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "9.2 Backup", 2)
    add_para(doc, "O arquivo contém manifesto com versão, data, identificador do sistema, contagem por entidade e checksum. Inclui anos letivos, disciplinas, turmas, alunos, matrículas, números de chamada, registros, catálogo, favoritos, configurações e dados necessários de usuários.")
    add_para(doc, "Não inclui PDFs temporários de importação, sessões ativas ou PDFs gerados de relatórios.")

    add_heading(doc, "9.3 Restauração", 2)
    for item in [
        "Substituição integral, sem mesclagem.",
        "Validação de formato, versão, checksum e relacionamentos.",
        "Confirmação explícita antes de alterar dados.",
        "Transação única com rollback em caso de erro.",
        "Invalidação das sessões após sucesso.",
    ]:
        add_bullet(doc, item)
    add_callout(doc, "Atenção operacional", "A restauração substitui todos os dados atuais. A interface deverá deixar esse efeito claro antes da confirmação.", fill="FFF1F1", title_color=RED)

    add_heading(doc, "10. Cronograma de desenvolvimento", 1)
    schedule_rows = [
        ("1", "Fundação", "Autenticação, banco, estrutura modular e contexto global", "1 semana"),
        ("2", "Anos e disciplinas", "CRUD, validações e duplicação estrutural de ano letivo", "1 semana"),
        ("3", "Turmas e alunos", "CRUD, matrículas, número de chamada e importação nos dois modos", "1 semana"),
        ("4", "Registros", "Registro normal, coletivo, favoritos e Registro Rápido", "1 semana"),
        ("5", "Histórico e dashboard", "Filtros, Novo Registro e indicadores do contexto", "1 semana"),
        ("6", "Relatórios", "Filtros, ordenação, PDF A4 e disciplina no cabeçalho", "1 semana"),
        ("7", "Backup e qualidade", "Exportação, restauração, segurança, testes e homologação", "1 semana"),
    ]
    add_table(doc, ["Etapa", "Área", "Entregas", "Estimativa"], schedule_rows, [700, 1900, 5000, 1760], font_size=8.8)

    add_heading(doc, "11. Critérios de aceite", 1)
    acceptance = [
        "Toda turma exige um ano letivo e nunca aparece fora do ano selecionado.",
        "Duplicar ano cria as turmas estruturais e não cria alunos, matrículas, números de chamada ou registros.",
        "Duplicação é transacional e não deixa dados parciais.",
        "Importação exige escolher um modo antes da confirmação.",
        "Adicionar apenas novos alunos mantém matrículas atuais e registros.",
        "Substituir lista substitui somente as matrículas da turma e preserva registros históricos.",
        "Número de chamada aparece na lista da turma e é opcional.",
        "Registro coletivo cria um registro individual por aluno matriculado no momento.",
        "Registro Rápido grava na lista sem exigir navegação para outra tela.",
        "Novo Registro funciona dentro da ficha do aluno.",
        "Favoritos aparecem primeiro no lançamento normal e no Registro Rápido.",
        "Relatórios aceitam aluno, turma, ano, período e ordenação por data/categoria.",
        "Relatórios são gerados em A4 e exibem disciplina quando vinculada.",
        "Backup inclui todas as entidades previstas e checksum válido.",
        "Restauração substitui integralmente os dados apenas após confirmação.",
        "Restauração rejeita arquivo corrompido, incompleto ou incompatível.",
        "Dashboard exibe total de turmas, total de alunos, hoje, mês e últimos registros.",
        "Pesquisa global localiza aluno e turma considerando o ano letivo.",
        "Histórico permite filtrar todas as categorias e registros personalizados.",
        "A terminologia principal em telas, APIs, banco e documentação é Registro.",
    ]
    for item in acceptance:
        add_bullet(doc, item)

    add_heading(doc, "12. Expansões futuras", 1)
    for item in [
        "Múltiplas instituições e isolamento por organização.",
        "Perfis adicionais e permissões configuráveis.",
        "Auditoria detalhada e histórico de versões.",
        "OCR para PDFs escaneados.",
        "Integrações com sistemas escolares.",
        "Notificações para responsáveis.",
        "Anexos, evidências e assinatura digital.",
        "Aplicativo mobile e modo offline.",
        "Importação em Excel ou CSV.",
        "Backup incremental e agendamento automático.",
        "Relatórios analíticos e indicadores pedagógicos.",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "Decisões e limites da v1", 1)
    add_callout(doc, "Mantido", "A arquitetura continua modular monolítica, com Next.js, TypeScript, PostgreSQL, Prisma, Professor único, registros individuais/coletivos, PDF textual de entrada e PDF A4 de saída.")
    add_callout(doc, "Fora do escopo", "OCR, mesclagem de backups, cópia de alunos na duplicação de ano, exclusão de registros na substituição de lista, perfis administrativos, notificações e integrações externas.", fill="FFF8E8", title_color=GOLD)

    doc.core_properties.title = "Registro Escolar - Documentação técnica v1"
    doc.core_properties.subject = "Especificação arquitetural e funcional"
    doc.core_properties.author = "Equipe do projeto Registro Escolar"
    doc.core_properties.keywords = "Registro Escolar, arquitetura, documentação técnica, versão 1"

    doc.save(OUT)
    return OUT


if __name__ == "__main__":
    path = build_document()
    print(path)
